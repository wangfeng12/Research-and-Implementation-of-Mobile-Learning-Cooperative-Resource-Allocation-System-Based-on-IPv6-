package com.example.file_picker.utils;

/**
 * 作者：Leon
 * 时间：2017/3/21 15:06
 *
 */
public class Constant {
    //返回图标风格
    public static final int BACKICON_STYLEONE = 0;
    public static final int BACKICON_STYLETWO = 1;
    public static final int BACKICON_STYLETHREE = 2;
    //图标风格
    public static final int ICON_STYLE_YELLOW = 0;
    public static final int ICON_STYLE_BLUE = 1;
    public static final int ICON_STYLE_GREEN = 2;

    public static String RESULT_INFO_PATHS = "paths";
    public static String RESULT_INFO_ALL_SIZE = "allSize";
    public static String RESULT_INFO_FAILED_PATHS = "failedPaths";
    public static String RESULT_INFO_SUCCEED_PATHS = "succeedPaths";


    public static int RESULT_OK = -1;
    public static int RESULT_CANCELED = 0;
    public static int RESULT_BACK = 1;


}
