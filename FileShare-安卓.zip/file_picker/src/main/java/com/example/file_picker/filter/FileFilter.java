package com.example.file_picker.filter;

import java.io.File;

public class FileFilter implements java.io.FileFilter {
    private String[] mTypes;

    public FileFilter(String[] types) {
        this.mTypes = types;
    }

    public boolean accept(File file) {
        if (file.isDirectory()) {
            return true;
        }
        if (mTypes != null && mTypes.length > 0) {
            for (int i = 0; i < mTypes.length; i++) {
                if (file.getName().endsWith(mTypes[i].toLowerCase()) || file.getName().endsWith(mTypes[i].toUpperCase())) {
                    return true;
                }
            }
        }else {
            return true;
        }
        return false;
    }
}
