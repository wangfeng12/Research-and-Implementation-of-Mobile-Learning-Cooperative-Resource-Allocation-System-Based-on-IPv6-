package com.example.file_picker.model;

import java.io.Serializable;

public class FileEntity implements Serializable {
  public String path;
  public String type;

  public FileEntity(String path, String type) {
    this.path = path;
    this.type = type;
  }
}
