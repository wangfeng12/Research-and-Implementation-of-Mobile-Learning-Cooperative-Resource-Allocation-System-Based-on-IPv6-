package com.example.file_picker.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.file_picker.R;
import com.example.file_picker.adapter.PathAdapter;
import com.example.file_picker.filter.FileFilter;
import com.example.file_picker.model.FileEntity;
import com.example.file_picker.model.ParamEntity;
import com.example.file_picker.utils.Constant;
import com.example.file_picker.utils.FileUtils;
import com.example.file_picker.utils.StringUtils;
import com.example.file_picker.widget.EmptyRecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FilePickerActivity extends AppCompatActivity {

  private final String TAG = "FilePicker";
  private EmptyRecyclerView mRecylerView;
  private View mEmptyView;
  private TextView mTvPath;
  private TextView mTvBack;
  private Button mBtnAddBook;
  private String mPath;
  private List<File> mListFiles;
  private ArrayList<FileEntity> mListNumbers = new ArrayList<>();//存放选中条目的数据地址
  private PathAdapter mPathAdapter;
  private Toolbar mToolbar;
  private ParamEntity mParamEntity;
  private FileFilter mFilter;
  private boolean mIsAllSelected = false;
  private Menu mMenu;
  private String mStartPath;
  private boolean isWifiP2p;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    mParamEntity = (ParamEntity) getIntent().getExtras().getSerializable("param");
    setTheme(mParamEntity.getTheme());
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_lfile_picker);
    initView();
    setSupportActionBar(mToolbar);
    getSupportActionBar().setHomeButtonEnabled(true);
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    initToolbar();
    updateAddButton();
    if (!checkSDState()) {
      Toast.makeText(this, R.string.lfile_NotFoundPath, Toast.LENGTH_SHORT).show();
      return;
    }
    isWifiP2p = mParamEntity.isWifiP2p();
    mPath = mParamEntity.getPath();
    if (StringUtils.isEmpty(mPath)) {
      //如果没有指定路径，则使用默认路径
      mPath = Environment.getExternalStorageDirectory().getAbsolutePath();
    }
    this.mStartPath = mPath;
    mTvPath.setText(mPath);
    mFilter = new FileFilter(mParamEntity.getFileTypes());
    mListFiles = FileUtils.getFileList(mPath, mFilter, mParamEntity.isGreater(), mParamEntity.getFileSize());
    mPathAdapter = new PathAdapter(FilePickerActivity.this, mListFiles, this, mFilter, mParamEntity.isMutilyMode(), mParamEntity.isGreater(), mParamEntity.getFileSize());
    mRecylerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
    mPathAdapter.setmIconStyle(mParamEntity.getIconStyle());
    mRecylerView.setAdapter(mPathAdapter);
    mRecylerView.setEmptyView(mEmptyView);
    initListener();
  }

  /**
   * 更新Toolbar展示
   */
  private void initToolbar() {
    if (mParamEntity.getTitle() != null) {
      mToolbar.setTitle(mParamEntity.getTitle());
    }
    if (mParamEntity.getTitleStyle() != 0) {
      mToolbar.setTitleTextAppearance(this, mParamEntity.getTitleStyle());
    }
    if (mParamEntity.getTitleColor() != null) {
      mToolbar.setTitleTextColor(Color.parseColor(mParamEntity.getTitleColor())); //设置标题颜色
    }
    if (mParamEntity.getBackgroundColor() != null) {
      mToolbar.setBackgroundColor(Color.parseColor(mParamEntity.getBackgroundColor()));
    }
//        switch (mParamEntity.getBackIcon()) {
//            case Constant.BACKICON_STYLEONE:
//                mToolbar.setNavigationIcon(R.mipmap.lfile_back1);
//                break;
//            case Constant.BACKICON_STYLETWO:
//                mToolbar.setNavigationIcon(R.mipmap.lfile_back2);
//                break;
//            case Constant.BACKICON_STYLETHREE:
//                //默认风格
//                break;
//        }
    mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent();
        setResult(Constant.RESULT_BACK, intent);
        finish();
      }
    });
  }

  public List<FileEntity> getSelectFilePaths() {
    return mListNumbers;
  }

  private void updateAddButton() {
    if (!mParamEntity.isMutilyMode()) {
      mBtnAddBook.setVisibility(View.GONE);
    }
    if (!mParamEntity.isChooseMode()) {
      mBtnAddBook.setVisibility(View.VISIBLE);
      mBtnAddBook.setText(getString(R.string.lfile_OK));
      //文件夹模式默认为单选模式
      mParamEntity.setMutilyMode(false);
    }
  }

  /**
   * 添加点击事件处理
   */
  private void initListener() {
    // 返回目录上一级
    mTvBack.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (mStartPath.equals(mPath)) {
          return;
        }
        String tempPath = new File(mPath).getParent();
        if (tempPath == null) {
          return;
        }
        mPath = tempPath;
        mListFiles = FileUtils.getFileList(mPath, mFilter, mParamEntity.isGreater(), mParamEntity.getFileSize());
        mPathAdapter.setmListData(mListFiles);
        mPathAdapter.updateAllSelelcted(false);
        mIsAllSelected = false;
        updateMenuTitle();

        mBtnAddBook.setText(getString(R.string.lfile_Selected) + "（" + mListNumbers.size() + "）");

        mRecylerView.scrollToPosition(0);
        setShowPath(mPath);
        //清除添加集合中数据
//        mListNumbers.clear();
        if (mParamEntity.getAddText() != null) {
          mBtnAddBook.setText(mParamEntity.getAddText());
        } else {
          mBtnAddBook.setText(getString(R.string.lfile_Selected) + "（" + mListNumbers.size() + "）");
        }
      }
    });
    mPathAdapter.setOnItemClickListener(new PathAdapter.OnItemClickListener() {
      public void click(int position) {
        if (mParamEntity.isMutilyMode()) {
          if (mListFiles.get(position).isDirectory()) {
            //如果当前是目录，则进入继续查看目录
            chekInDirectory(position);
            mPathAdapter.updateAllSelelcted(false);
            mIsAllSelected = false;
            updateMenuTitle();
            mBtnAddBook.setText(getString(R.string.lfile_Selected) + "（" + mListNumbers.size() + "）");
          } else {
            //如果已经选择则取消，否则添加进来
            boolean isContains = false;
            for (FileEntity entity : mListNumbers) {
              if (entity.path.contains(mListFiles.get(position).getAbsolutePath())) {
                isContains = true;
                break;
              }
            }
            if (isContains) {
              Iterator<FileEntity> tList = mListNumbers.iterator();
              while (tList.hasNext()) {
                FileEntity entity = tList.next();
                if (entity.path.contains(mListFiles.get(position).getAbsolutePath())) {
                  tList.remove();
                }
              }
//              for (FileEntity entity : mListNumbers) {
//                if (entity.path.contains(mListFiles.get(position).getAbsolutePath())) {
//                  mListNumbers.remove(entity);
//                }
//              }
            } else {
              if (isWifiP2p) {
                FileEntity entity = new FileEntity(mListFiles.get(position).getAbsolutePath(), "");
                mListNumbers.add(entity);
                chooseDone();
                return;
              } else
                dialogChoice(mListFiles.get(position));
            }
            if (mParamEntity.getAddText() != null) {
              mBtnAddBook.setText(mParamEntity.getAddText() + "( " + mListNumbers.size() + " )");
            } else {
              mBtnAddBook.setText(getString(R.string.lfile_Selected) + "( " + mListNumbers.size() + " )");
            }
            //先判断是否达到最大数量，如果数量达到上限提示，否则继续添加
            if (mParamEntity.getMaxNum() > 0 && mListNumbers.size() > mParamEntity.getMaxNum()) {
              Toast.makeText(FilePickerActivity.this, R.string.lfile_OutSize, Toast.LENGTH_SHORT).show();
              return;
            }
          }
        } else {
          //单选模式直接返回
          if (mListFiles.get(position).isDirectory()) {
            chekInDirectory(position);
            return;
          }
          if (mParamEntity.isChooseMode()) {
            //选择文件模式,需要添加文件路径，否则为文件夹模式，直接返回当前路径
            dialogChoice(mListFiles.get(position));

            chooseDone();
          } else {
            Toast.makeText(FilePickerActivity.this, R.string.lfile_ChooseTip, Toast.LENGTH_SHORT).show();
          }
        }

      }
    });

    mBtnAddBook.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (mParamEntity.isChooseMode() && mListNumbers.size() < 1) {
          String info = mParamEntity.getNotFoundFiles();
          if (TextUtils.isEmpty(info)) {
            Toast.makeText(FilePickerActivity.this, R.string.lfile_NotFoundBooks, Toast.LENGTH_SHORT).show();
          } else {
            Toast.makeText(FilePickerActivity.this, info, Toast.LENGTH_SHORT).show();
          }
        } else {
          //返回
          chooseDone();
        }
      }
    });
  }


  /**
   * 点击进入目录
   *
   * @param position
   */
  private void chekInDirectory(int position) {
    mPath = mListFiles.get(position).getAbsolutePath();
    setShowPath(mPath);
    //更新数据源
    mListFiles = FileUtils.getFileList(mPath, mFilter, mParamEntity.isGreater(), mParamEntity.getFileSize());
    mPathAdapter.setmListData(mListFiles);
    mPathAdapter.notifyDataSetChanged();
    mRecylerView.scrollToPosition(0);
  }

  /**
   * 完成提交
   */
  private void chooseDone() {
    //判断是否数量符合要求
    if (mParamEntity.isChooseMode()) {
      if (mParamEntity.getMaxNum() > 0 && mListNumbers.size() > mParamEntity.getMaxNum()) {
        Toast.makeText(FilePickerActivity.this, R.string.lfile_OutSize + mParamEntity.getMaxNum(), Toast.LENGTH_SHORT).show();
        return;
      }
    }
    long allFileSize = 0;

    for (FileEntity entity : mListNumbers) {
      allFileSize += new File(entity.path).length();
    }

    Intent intent = new Intent();
    intent.putExtra("paths", mListNumbers);
    intent.putExtra("path", mTvPath.getText().toString().trim());
    intent.putExtra(Constant.RESULT_INFO_ALL_SIZE, FileUtils.getReadableFileSize(allFileSize));
    setResult(RESULT_OK, intent);
    this.finish();
  }

  /**
   * 初始化控件
   */
  private void initView() {
    mRecylerView = (EmptyRecyclerView) findViewById(R.id.recylerview);
    mTvPath = (TextView) findViewById(R.id.tv_path);
    mTvBack = (TextView) findViewById(R.id.tv_back);
    mBtnAddBook = (Button) findViewById(R.id.btn_addbook);
    mEmptyView = findViewById(R.id.empty_view);
    mToolbar = (Toolbar) findViewById(R.id.toolbar);
    if (mParamEntity.getAddText() != null) {
      mBtnAddBook.setText(mParamEntity.getAddText());
    }
  }

  /**
   * 检测SD卡是否可用
   */
  private boolean checkSDState() {
    return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
  }

  /**
   * 显示顶部地址
   *
   * @param path
   */
  private void setShowPath(String path) {
    mTvPath.setText(path);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_main_toolbar, menu);
    this.mMenu = menu;
    updateOptionsMenu(menu);
    return true;
  }

  /**
   * 更新选项菜单展示，如果是单选模式，不显示全选操作
   *
   * @param menu
   */
  private void updateOptionsMenu(Menu menu) {
    mMenu.findItem(R.id.action_selecteall_cancel).setVisible(mParamEntity.isMutilyMode());
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.action_selecteall_cancel) {
      //将当前目录下所有文件选中或者取消
      mPathAdapter.updateAllSelelcted(!mIsAllSelected);
      mIsAllSelected = !mIsAllSelected;
      if (mIsAllSelected) {
        for (File mListFile : mListFiles) {
          //不包含再添加，避免重复添加
          boolean isContains = false;
          for (FileEntity entity : mListNumbers) {
            if (entity.path.contains(mListFile.getAbsolutePath())) {
              isContains = true;
              break;
            }
          }
          if (!mListFile.isDirectory() && !isContains) {
            dialogChoice(mListFile);
          }
          if (mParamEntity.getAddText() != null) {
            mBtnAddBook.setText(mParamEntity.getAddText() + "( " + mListNumbers.size() + " )");
          } else {
            mBtnAddBook.setText(getString(R.string.lfile_Selected) + "( " + mListNumbers.size() + " )");
          }
        }
      } else {
//        mListNumbers.clear();
//        mBtnAddBook.setText(getString(R.string.lfile_Selected));
        mBtnAddBook.setText(getString(R.string.lfile_Selected) + "( " + mListNumbers.size() + " )");
      }
      updateMenuTitle();
    }
    return true;
  }

  /**
   * 更新选项菜单文字
   */
  public void updateMenuTitle() {

    if (mIsAllSelected) {
      mMenu.getItem(0).setTitle(getString(R.string.lfile_Cancel));
    } else {
      mMenu.getItem(0).setTitle(getString(R.string.lfile_SelectAll));
    }
  }

  /**
   * 单选
   */
  private void dialogChoice(final File file) {
    final String items[] = {"政治", "视频", "书籍", "音乐", "娱乐", "体育", "应用", "图片", "摄影写真", "丽人"};
    AlertDialog.Builder builder = new AlertDialog.Builder(this, 0);
    builder.setTitle("请选择分类");
    builder.setSingleChoiceItems(items, 0,
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which) {
            FileEntity entity = new FileEntity(file.getAbsolutePath(), items[which]);
            mListNumbers.add(entity);
            runOnUiThread(new Runnable() {
              public void run() {
                mBtnAddBook.setText(getString(R.string.lfile_Selected) + "( " + mListNumbers.size() + " )");
              }
            });
            dialog.dismiss();
          }
        });
//    builder.setNegativeButton("取消", null);
    AlertDialog alertDialog = builder.create();
    alertDialog.setCanceledOnTouchOutside(false);
    alertDialog.show();
  }
}
