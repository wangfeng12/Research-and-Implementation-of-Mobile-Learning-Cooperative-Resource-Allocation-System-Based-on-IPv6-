package com.mpv.blelibrary.bt;

import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.file_picker.FilePicker;
import com.example.file_picker.model.FileEntity;
import com.example.file_picker.utils.Constant;
import com.mpv.blelibrary.R;

import java.io.File;
import java.util.List;

public class BtServerActivity extends AppCompatActivity implements BtBase.Listener {
  private TextView mTips;
  private EditText mInputMsg;
  private TextView mInputFile;
  private TextView mLogs;
  private BtServer mServer;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_btserver);
    TextView titleNameTv = this.findViewById(R.id.tv_title_name);
    titleNameTv.setText("蓝牙服务端");
    this.findViewById(R.id.iv_title_back).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        finish();
      }
    });
    mTips = findViewById(R.id.tv_tips);
    mInputMsg = findViewById(R.id.input_msg);
    mInputFile = findViewById(R.id.input_file);
    mInputFile.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        openFilePicker();
      }
    });
    mLogs = findViewById(R.id.tv_log);
    mServer = new BtServer(this);
  }

  protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Constant.RESULT_OK) {
      if (requestCode == 422) {
        List<FileEntity> currentSelectedFilePaths = (List<FileEntity>) data.getSerializableExtra(Constant.RESULT_INFO_PATHS);
        if (currentSelectedFilePaths.size() > 0) {
          //发送文件
          if (currentSelectedFilePaths.get(0).path != null && !currentSelectedFilePaths.get(0).path.isEmpty()) {
            String path = currentSelectedFilePaths.get(0).path;
            File file = new File(path);
            if (file.exists()) {
              mInputFile.setText(path);
            }
          }
        }
      }
    }
  }

  private void openFilePicker() {
    new FilePicker()
        .withActivity(BtServerActivity.this)
        .withRequestCode(422)
        .withTitle("文件选择")
//                .withIconStyle(mIconType)
//                .withMutilyMode(false)
        .withMaxNum(1)
        .isWifiP2p(true)
        .withStartPath("/storage/emulated/0")//指定初始显示路径
        .withNotFoundBooks("至少选择一个文件")
        .withIsGreater(false)//过滤文件大小 小于指定大小的文件
        .withFileSize(500 * 1024 * 1024)//指定文件大小为500K
//                .withChooseMode(true)//文件夹选择模式
        //.withFileFilter(new String[]{"txt", "png", "docx"})
        .start();
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    mServer.unListener();
    mServer.close();
  }

  public void sendMsg(View view) {
    if (mServer.isConnected(null)) {
      String msg = mInputMsg.getText().toString();
      if (TextUtils.isEmpty(msg))
        Toast.makeText(this, "消息不能空", Toast.LENGTH_SHORT).show();
      else
        mServer.sendMsg(msg);
    } else
      Toast.makeText(this, "没有连接", Toast.LENGTH_SHORT).show();
  }

  public void sendFile(View view) {
    if (mServer.isConnected(null)) {
      String filePath = mInputFile.getText().toString();
      if (TextUtils.isEmpty(filePath) || !new File(filePath).isFile())
        Toast.makeText(this, "文件无效", Toast.LENGTH_SHORT).show();
      else
        mServer.sendFile(filePath);
    } else
      Toast.makeText(this, "没有连接", Toast.LENGTH_SHORT).show();
  }

  @Override
  public void socketNotify(int state, final Object obj) {
    if (isDestroyed())
      return;
    String msg = null;
    switch (state) {
      case BtBase.Listener.CONNECTED:
        BluetoothDevice dev = (BluetoothDevice) obj;
        msg = String.format("与%s(%s)连接成功", dev.getName(), dev.getAddress());
        mTips.setText(msg);
        break;
      case BtBase.Listener.DISCONNECTED:
        mServer.listen();
        msg = "连接断开,正在重新监听...";
        mTips.setText(msg);
        break;
      case BtBase.Listener.MSG:
        msg = String.format("\n%s", obj);
        mLogs.append(msg);
        break;
    }
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  }
}