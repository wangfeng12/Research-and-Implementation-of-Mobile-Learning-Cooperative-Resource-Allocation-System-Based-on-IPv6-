package com.mprv.wifip2p;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.p2p.WifiP2pDevice;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class WifiP2pActivity extends AppCompatActivity {
  private static final int CODE_REQ_PERMISSIONS = 665;

  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_wiwi_p2p);
    TextView titleNameTv = this.findViewById(R.id.tv_title_name);
    titleNameTv.setText("WIFI - 文件分享");
    this.findViewById(R.id.iv_title_back).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        finish();
      }
    });
    this.findViewById(R.id.send_file_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        startFileSenderActivity();
      }
    });
    this.findViewById(R.id.receive_file_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        startFileReceiverActivity();
      }
    });

    checkPermission();
  }

  public void startFileSenderActivity() {
    startActivity(new Intent(this, SendFileActivity.class));
  }

  public void startFileReceiverActivity() {
    startActivity(new Intent(this, ReceiveFileActivity.class));
  }

  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == CODE_REQ_PERMISSIONS) {
      for (int i = 0; i < grantResults.length; i++) {
        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
          showToast("缺少权限，请先授予权限");
          showToast(permissions[i]);
          return;
        }
      }
      showToast("已获得权限");
    }
  }

  public void checkPermission() {
    ActivityCompat.requestPermissions(WifiP2pActivity.this,
        new String[]{Manifest.permission.CHANGE_NETWORK_STATE, Manifest.permission.ACCESS_NETWORK_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION}, CODE_REQ_PERMISSIONS);
  }

  public static String getDeviceStatus(int deviceStatus) {
    switch (deviceStatus) {
      case WifiP2pDevice.AVAILABLE:
        return "可用的";
      case WifiP2pDevice.INVITED:
        return "邀请中";
      case WifiP2pDevice.CONNECTED:
        return "已连接";
      case WifiP2pDevice.FAILED:
        return "失败的";
      case WifiP2pDevice.UNAVAILABLE:
        return "不可用的";
      default:
        return "未知";
    }
  }

  private void showToast(String message) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
  }
}