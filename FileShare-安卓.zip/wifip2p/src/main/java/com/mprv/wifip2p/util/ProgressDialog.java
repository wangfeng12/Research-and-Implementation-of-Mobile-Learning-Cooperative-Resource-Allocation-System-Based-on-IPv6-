package com.mprv.wifip2p.util;

import android.content.Context;

import com.afollestad.materialdialogs.MaterialDialog;

public class ProgressDialog {

  private static volatile ProgressDialog instance;

  private ProgressDialog() {
  }

  public static ProgressDialog getInstance() {
    if (instance == null) {
      synchronized (ProgressDialog.class) {
        if (instance == null) {
          instance = new ProgressDialog();
        }
      }
    }
    return instance;
  }

  private MaterialDialog materialDialog;

  public void show(Context mContext, String message) {
    materialDialog = new MaterialDialog.Builder(mContext)
//                .title(R.string.progress_dialog_title)
        .content(message)
        .progress(true, 0)
        .cancelable(false)
        .progressIndeterminateStyle(false)
        .show();

  }

  public void show(Context mContext) {
    materialDialog = new MaterialDialog.Builder(mContext)
//                .title(R.string.progress_dialog_title)
        .content("正在加载...")
        .progress(true, 0)
        .cancelable(false)
        .progressIndeterminateStyle(false)
        .show();

  }

  public void dismiss() {
    if (materialDialog != null)
      materialDialog.dismiss();
  }

  public void setContentString(String content) {
    if (materialDialog != null && materialDialog.isShowing()) {
      materialDialog.setContent(content);
    }
  }
}
