package com.mprv.wifip2p.common;

/**
 * 作者：leavesC
 * 时间：2019/11/23 17:54
 * 描述：
 */
public class Constants {

    public static final int PORT = 1995;

}
