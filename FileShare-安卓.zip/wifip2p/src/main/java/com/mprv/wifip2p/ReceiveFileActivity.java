package com.mprv.wifip2p;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.StrictMode;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.mprv.wifip2p.broadcast.DirectBroadcastReceiver;
import com.mprv.wifip2p.callback.DirectActionListener;
import com.mprv.wifip2p.model.FileTransfer;
import com.mprv.wifip2p.service.WifiServerService;

import java.io.File;
import java.util.Collection;

public class ReceiveFileActivity extends AppCompatActivity {
  private TextView tv_log;
  private WifiP2pManager wifiP2pManager;
  private WifiP2pManager.Channel channel;
  private boolean connectionInfoAvailable;

  private DirectActionListener directActionListener = new DirectActionListener() {
    public void wifiP2pEnabled(boolean enabled) {
      log("wifi是否开启: " + enabled);
    }

    public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
//      log("群组创建");
//      log("是否为群组使用者：" + wifiP2pInfo.isGroupOwner);
//      log("是否为群组拥有者：" + wifiP2pInfo.groupFormed);
      if (wifiP2pInfo.groupFormed && wifiP2pInfo.isGroupOwner) {
        connectionInfoAvailable = true;
        if (wifiServerService != null) {
          startService(new Intent(ReceiveFileActivity.this, WifiServerService.class));
        }
      }
    }

    public void onDisconnection() {
      connectionInfoAvailable = false;
      log("未连接群组");
    }

    public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {
      log("onSelfDeviceAvailable");
      log(wifiP2pDevice.toString());
    }

    public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {
      log("onPeersAvailable,size:" + wifiP2pDeviceList.size());
      for (WifiP2pDevice wifiP2pDevice : wifiP2pDeviceList) {
        log(wifiP2pDevice.toString());
      }
    }

    public void onChannelDisconnected() {
      log("群组连接失败");
    }
  };

  private BroadcastReceiver broadcastReceiver;

  private WifiServerService wifiServerService;

  private ProgressDialog progressDialog;

  private ServiceConnection serviceConnection = new ServiceConnection() {
    public void onServiceConnected(ComponentName name, IBinder service) {
      WifiServerService.MyBinder binder = (WifiServerService.MyBinder) service;
      wifiServerService = binder.getService();
      wifiServerService.setProgressChangListener(progressChangListener);
    }

    public void onServiceDisconnected(ComponentName name) {
      wifiServerService = null;
      bindService();
    }
  };

  private WifiServerService.OnProgressChangListener progressChangListener = new WifiServerService.OnProgressChangListener() {
    public void onProgressChanged(final FileTransfer fileTransfer, final int progress) {
      runOnUiThread(new Runnable() {
        public void run() {
          progressDialog.setMessage("文件名： " + new File(fileTransfer.getFilePath()).getName());
          progressDialog.setProgress(progress);
          progressDialog.show();
        }
      });
    }

    public void onTransferFinished(final File file) {
      runOnUiThread(new Runnable() {
        public void run() {
          progressDialog.cancel();
          if (file != null && file.exists()) {
            openFile(file.getPath());
          }
        }
      });
    }
  };

  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_receive_file);
    TextView titleNameTv = this.findViewById(R.id.tv_title_name);
    titleNameTv.setText("接收文件");
    this.findViewById(R.id.iv_title_back).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        finish();
      }
    });
    initView();
    wifiP2pManager = (WifiP2pManager) getSystemService(WIFI_P2P_SERVICE);
    if (wifiP2pManager == null) {
      finish();
      return;
    }
    channel = wifiP2pManager.initialize(this, getMainLooper(), directActionListener);
    broadcastReceiver = new DirectBroadcastReceiver(wifiP2pManager, channel, directActionListener);
    registerReceiver(broadcastReceiver, DirectBroadcastReceiver.getIntentFilter());
    bindService();
    this.findViewById(R.id.btn_createGroup).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        createGroup();
      }
    });
    this.findViewById(R.id.btn_removeGroup).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        removeGroup();
      }
    });
  }

  private void initView() {
    tv_log = findViewById(R.id.tv_log);
    progressDialog = new ProgressDialog(this);
    progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    progressDialog.setCancelable(false);
    progressDialog.setCanceledOnTouchOutside(false);
    progressDialog.setTitle("正在接收文件");
    progressDialog.setMax(100);
  }

  protected void onDestroy() {
    super.onDestroy();
    if (wifiServerService != null) {
      wifiServerService.setProgressChangListener(null);
      unbindService(serviceConnection);
    }
    unregisterReceiver(broadcastReceiver);
    stopService(new Intent(this, WifiServerService.class));
    if (connectionInfoAvailable) {
      removeGroup();
    }
  }

  public void createGroup() {
    wifiP2pManager.createGroup(channel, new WifiP2pManager.ActionListener() {
      public void onSuccess() {
        log("createGroup onSuccess");
        showToast("onSuccess");
      }

      public void onFailure(int reason) {
        log("createGroup onFailure: " + reason);
//        dismissLoadingDialog();
        showToast("onFailure");
      }
    });
  }

  private void removeGroup() {
    wifiP2pManager.removeGroup(channel, new WifiP2pManager.ActionListener() {
      public void onSuccess() {
        log("群组已移除");
        showToast("群组已移除");
      }

      public void onFailure(int reason) {
        log("移除群组失败");
        showToast("移除群组失败");
      }
    });
  }

  private void log(String log) {
    tv_log.append(log + "\n");
    tv_log.append("----------" + "\n");
  }

  private void bindService() {
    Intent intent = new Intent(ReceiveFileActivity.this, WifiServerService.class);
    bindService(intent, serviceConnection, BIND_AUTO_CREATE);
  }

  private void showToast(String msg) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  }

  private void openFile(String filepath) {
    Intent intent = new Intent();
    // 这是比较流氓的方法，绕过7.0的文件权限检查
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
      StrictMode.setVmPolicy(builder.build());
    }

    File file = new File(filepath);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//设置标记
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    intent.setAction(Intent.ACTION_VIEW);//动作，查看
    intent.setDataAndType(Uri.fromFile(file), WifiConstant.getMIMEType(file));//设置类型
    startActivity(intent);
  }
}