package com.mprv.wifip2p;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.file_picker.FilePicker;
import com.example.file_picker.model.FileEntity;
import com.example.file_picker.utils.Constant;
import com.mprv.wifip2p.adapter.DeviceAdapter;
import com.mprv.wifip2p.broadcast.DirectBroadcastReceiver;
import com.mprv.wifip2p.callback.DirectActionListener;
import com.mprv.wifip2p.model.FileTransfer;
import com.mprv.wifip2p.task.WifiClientTask;
import com.mprv.wifip2p.util.ProgressDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SendFileActivity extends AppCompatActivity {

  private static final String TAG = "SendFileActivity";

  private TextView tv_myDeviceName;
  private TextView tv_myDeviceAddress;
  private TextView tv_myDeviceStatus;
  private TextView tv_status;
  private List<WifiP2pDevice> wifiP2pDeviceList;
  private DeviceAdapter deviceAdapter;
  private Button btn_search;
  private Button btn_disconnect;
  private Button btn_chooseFile;
  private BroadcastReceiver broadcastReceiver;
  private WifiP2pDevice mWifiP2pDevice;
  private WifiP2pManager wifiP2pManager;
  private WifiP2pManager.Channel channel;
  private WifiP2pInfo wifiP2pInfo;
  private boolean wifiP2pEnabled = false;
  private DirectActionListener directActionListener = new DirectActionListener() {

    public void wifiP2pEnabled(boolean enabled) {
      wifiP2pEnabled = enabled;
    }

    public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
      ProgressDialog.getInstance().dismiss();
      wifiP2pDeviceList.clear();
      deviceAdapter.notifyDataSetChanged();
      btn_disconnect.setVisibility(View.VISIBLE);
      btn_chooseFile.setVisibility(View.VISIBLE);
      Log.e(TAG, "onConnectionInfoAvailable");
      Log.e(TAG, "onConnectionInfoAvailable groupFormed: " + wifiP2pInfo.groupFormed);
      Log.e(TAG, "onConnectionInfoAvailable isGroupOwner: " + wifiP2pInfo.isGroupOwner);
      Log.e(TAG, "onConnectionInfoAvailable getHostAddress: " + wifiP2pInfo.groupOwnerAddress.getHostAddress());
      StringBuilder stringBuilder = new StringBuilder();
      if (mWifiP2pDevice != null) {
        stringBuilder.append("连接的设备名：");
        stringBuilder.append(mWifiP2pDevice.deviceName);
        stringBuilder.append("\n");
        stringBuilder.append("连接的设备的地址：");
        stringBuilder.append(mWifiP2pDevice.deviceAddress);
      }
      stringBuilder.append("\n");
      stringBuilder.append("是否群主：");
      stringBuilder.append(wifiP2pInfo.isGroupOwner ? "是群主" : "非群主");
      stringBuilder.append("\n");
      stringBuilder.append("群主IP地址：");
      stringBuilder.append(wifiP2pInfo.groupOwnerAddress.getHostAddress());
      tv_status.setText(stringBuilder);
      if (wifiP2pInfo.groupFormed && !wifiP2pInfo.isGroupOwner) {
        SendFileActivity.this.wifiP2pInfo = wifiP2pInfo;
      }
    }

    public void onDisconnection() {
      Log.e(TAG, "onDisconnection");
      btn_disconnect.setVisibility(View.GONE);
      btn_chooseFile.setVisibility(View.GONE);
      showToast("处于非连接状态");
      wifiP2pDeviceList.clear();
      deviceAdapter.notifyDataSetChanged();
      tv_status.setText(null);
      SendFileActivity.this.wifiP2pInfo = null;
    }

    public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {
      Log.e(TAG, "onSelfDeviceAvailable");
      Log.e(TAG, "DeviceName: " + wifiP2pDevice.deviceName);
      Log.e(TAG, "DeviceAddress: " + wifiP2pDevice.deviceAddress);
      Log.e(TAG, "Status: " + wifiP2pDevice.status);
      tv_myDeviceName.setText(wifiP2pDevice.deviceName);
      tv_myDeviceAddress.setText(wifiP2pDevice.deviceAddress);
      tv_myDeviceStatus.setText(WifiP2pActivity.getDeviceStatus(wifiP2pDevice.status));
    }

    public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {
      Log.e(TAG, "onPeersAvailable :" + wifiP2pDeviceList.size());
      SendFileActivity.this.wifiP2pDeviceList.clear();
      SendFileActivity.this.wifiP2pDeviceList.addAll(wifiP2pDeviceList);
      deviceAdapter.notifyDataSetChanged();
      ProgressDialog.getInstance().dismiss();
    }

    public void onChannelDisconnected() {
      Log.e(TAG, "onChannelDisconnected");
    }

  };

  private List<FileEntity> currentSelectedFilePaths;

  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_send_file);
    TextView titleNameTv = this.findViewById(R.id.tv_title_name);
    titleNameTv.setText("发送文件");
    this.findViewById(R.id.iv_title_back).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        finish();
      }
    });
    initView();
    initEvent();
  }

  private void initEvent() {
    wifiP2pManager = (WifiP2pManager) getSystemService(WIFI_P2P_SERVICE);
    if (wifiP2pManager == null) {
      finish();
      return;
    }
    channel = wifiP2pManager.initialize(this, getMainLooper(), directActionListener);
    broadcastReceiver = new DirectBroadcastReceiver(wifiP2pManager, channel, directActionListener);
    registerReceiver(broadcastReceiver, DirectBroadcastReceiver.getIntentFilter());
  }

  private void initView() {
    setTitle("发送文件");
    tv_myDeviceName = findViewById(R.id.tv_myDeviceName);
    tv_myDeviceAddress = findViewById(R.id.tv_myDeviceAddress);
    tv_myDeviceStatus = findViewById(R.id.tv_myDeviceStatus);
    tv_status = findViewById(R.id.tv_status);
    btn_search = this.findViewById(R.id.btn_search);
    btn_search.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        searchWifiDevice();
      }
    });
    btn_disconnect = this.findViewById(R.id.btn_disconnect);
    btn_disconnect.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        disconnect();
      }
    });
    btn_disconnect.setVisibility(View.GONE);
    btn_chooseFile = findViewById(R.id.btn_chooseFile);
    btn_chooseFile.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        navToChose();
      }
    });
    btn_chooseFile.setVisibility(View.GONE);
    RecyclerView rv_deviceList = findViewById(R.id.rv_deviceList);
    wifiP2pDeviceList = new ArrayList<>();
    deviceAdapter = new DeviceAdapter(wifiP2pDeviceList);
    deviceAdapter.setClickListener(new DeviceAdapter.OnClickListener() {
      @Override
      public void onItemClick(int position) {
        mWifiP2pDevice = wifiP2pDeviceList.get(position);
        connect();
      }
    });
    rv_deviceList.setAdapter(deviceAdapter);
    rv_deviceList.setLayoutManager(new LinearLayoutManager(this));
  }

  private void searchWifiDevice() {
    if (!wifiP2pEnabled) {
      showToast("需要先打开Wifi");
      return;
    }
    ProgressDialog.getInstance().show(SendFileActivity.this, "正在搜索附近设备");
    wifiP2pDeviceList.clear();
    deviceAdapter.notifyDataSetChanged();
    //搜寻附近带有 Wi-Fi P2P 的设备
    wifiP2pManager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
      public void onSuccess() {
        showToast("搜索设备完成");
      }

      public void onFailure(int reasonCode) {
        showToast("搜索设备失败");
        ProgressDialog.getInstance().dismiss();
      }
    });
  }

  protected void onDestroy() {
    super.onDestroy();
    unregisterReceiver(broadcastReceiver);
  }

  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Constant.RESULT_OK) {
      if (requestCode == 412) {
        currentSelectedFilePaths = (List<FileEntity>) data.getSerializableExtra(Constant.RESULT_INFO_PATHS);
        if (currentSelectedFilePaths.size() > 0) {
          //发送文件
          if (currentSelectedFilePaths.get(0).path != null && !currentSelectedFilePaths.get(0).path.isEmpty()) {
            String path = currentSelectedFilePaths.get(0).path;
            Log.e(TAG, "文件路径：" + path);
            File file = new File(path);
            if (file.exists() && wifiP2pInfo != null) {
              FileTransfer fileTransfer = new FileTransfer(file.getPath(), file.length());
              new WifiClientTask(this, fileTransfer).execute(wifiP2pInfo.groupOwnerAddress.getHostAddress());
            }
          }
        }
      } else if (requestCode == 1001) {
        currentSelectedFilePaths.clear();
//        for (String path : failedFilePaths) {
//          currentSelectedFilePaths.add(new FileEntity(path, ""));
//        }
//        failedFilePaths.clear();
//        long failedFileSiz = 0;
//        for (FileEntity failedPath : currentSelectedFilePaths) {
//          failedFileSiz += new File(failedPath.path).length();
//        }
//        if (currentSelectedFilePaths.size() > 0) {
//          resetViewInfo(currentSelectedFilePaths.size(), FileUtils.getReadableFileSize(failedFileSiz));
//        }
      }
    } else if (resultCode == Constant.RESULT_CANCELED) {
//      UpFileActivity.this.finish();
    }
  }

  private void connect() {
    WifiP2pConfig config = new WifiP2pConfig();
    if (config.deviceAddress != null && mWifiP2pDevice != null) {
      config.deviceAddress = mWifiP2pDevice.deviceAddress;
      config.wps.setup = WpsInfo.PBC;
      ProgressDialog.getInstance().show(this, "正在连接 " + mWifiP2pDevice.deviceName);
      wifiP2pManager.connect(channel, config, new WifiP2pManager.ActionListener() {
        public void onSuccess() {
          showToast("设备连接已连接");
          ProgressDialog.getInstance().dismiss();
        }

        public void onFailure(int reason) {
          showToast("设备连接失败，错误码：" + reason);
          ProgressDialog.getInstance().dismiss();
        }
      });
    }
  }

  private void disconnect() {
    wifiP2pManager.removeGroup(channel, new WifiP2pManager.ActionListener() {
      public void onFailure(int reasonCode) {
        Log.e(TAG, "disconnect onFailure:" + reasonCode);
      }

      public void onSuccess() {
        Log.e(TAG, "disconnect onSuccess");
        tv_status.setText(null);
        btn_disconnect.setVisibility(View.GONE);
        btn_chooseFile.setVisibility(View.GONE);
      }
    });
  }

//  public boolean onOptionsItemSelected(MenuItem item) {
//    switch (item.getItemId()) {
//      case R.id.menuDirectEnable: {
//        if (wifiP2pManager != null && channel != null) {
//          startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
//        } else {
//          showToast("当前设备不支持Wifi Direct");
//        }
//        return true;
//      }
//      case R.id.menuDirectDiscover: {
//        if (!wifiP2pEnabled) {
//          showToast("需要先打开Wifi");
//          return true;
//        }
//        loadingDialog.show("正在搜索附近设备", true, false);
//        wifiP2pDeviceList.clear();
//        deviceAdapter.notifyDataSetChanged();
//        //搜寻附近带有 Wi-Fi P2P 的设备
//        wifiP2pManager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
//          @Override
//          public void onSuccess() {
//            showToast("Success");
//          }
//
//          @Override
//          public void onFailure(int reasonCode) {
//            showToast("Failure");
//            loadingDialog.cancel();
//          }
//        });
//        return true;
//      }
//      default:
//        return true;
//    }
//  }

  private void navToChose() {
    openFilePicker();
  }

  private void openFilePicker() {
    new FilePicker()
        .withActivity(SendFileActivity.this)
        .withRequestCode(412)
        .withTitle("文件选择")
//                .withIconStyle(mIconType)
//                .withMutilyMode(false)
        .withMaxNum(1)
        .isWifiP2p(true)
        .withStartPath("/storage/emulated/0")//指定初始显示路径
        .withNotFoundBooks("至少选择一个文件")
        .withIsGreater(false)//过滤文件大小 小于指定大小的文件
        .withFileSize(500 * 1024 * 1024)//指定文件大小为500K
//                .withChooseMode(true)//文件夹选择模式
        //.withFileFilter(new String[]{"txt", "png", "docx"})
        .start();
  }

  private void showToast(String msg) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  }
}