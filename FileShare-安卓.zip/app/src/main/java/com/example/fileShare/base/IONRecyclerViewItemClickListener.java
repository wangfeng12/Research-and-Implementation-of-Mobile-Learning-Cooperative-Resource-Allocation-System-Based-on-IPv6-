package com.example.fileShare.base;

import androidx.recyclerview.widget.RecyclerView;

public interface IONRecyclerViewItemClickListener {
  void onItemClick(RecyclerView.ViewHolder holder);
}
