package com.example.fileShare.search;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fileShare.R;
import com.example.fileShare.base.IONRecyclerViewItemClickListener;
import com.example.fileShare.search.dto.FileDto;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SearchFileAdapter extends RecyclerView.Adapter<SearchFileViewHolder> {
  public List<FileDto> list = new ArrayList<>();
  private IONRecyclerViewItemClickListener itemClickListener;

  public SearchFileViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
    View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_file, viewGroup, false);
    return new SearchFileViewHolder(view);
  }

  public void onBindViewHolder(@NonNull SearchFileViewHolder holder, int i) {
    FileDto moel = list.get(i);
    holder.fileName.setText(moel.filename);
    holder.fileUpdateTimeTv.setText("最后更新时间：" + moel.updateTime);
    if (itemClickListener != null) {
      holder.itemView.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
          itemClickListener.onItemClick(holder);
        }
      });
    }
  }

  public int getItemCount() {
    return list.size();
  }

  public void setItemClickListener(IONRecyclerViewItemClickListener itemClickListener) {
    this.itemClickListener = itemClickListener;
  }
}
