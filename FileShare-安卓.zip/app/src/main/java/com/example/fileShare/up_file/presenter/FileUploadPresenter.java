package com.example.fileShare.up_file.presenter;


import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;
import com.example.fileShare.net.RxScheduler;
import com.example.fileShare.up_file.contract.FileUploadContract;
import com.example.fileShare.up_file.model.FileUploadModel;

import java.io.File;

import io.reactivex.functions.Consumer;

public class FileUploadPresenter extends BasePresenter<FileUploadContract.View> implements FileUploadContract.Presenter {

  private FileUploadContract.Model model;

  public FileUploadPresenter() {
    model = new FileUploadModel();
  }

  public void uploadFile(String userId, File file, String localPath, int position, String type) {
    //View是否绑定 如果没有绑定，就不执行网络请求
    if (!isViewAttached()) {
      return;
    }
    model.uploadFile(userId, file, localPath, type)
        .compose(RxScheduler.<BaseObjectBean<FileUploadBean>>Flo_io_main())
        .as(mView.<BaseObjectBean<FileUploadBean>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<FileUploadBean>>() {
          public void accept(BaseObjectBean<FileUploadBean> bean) throws Exception {
            if (bean.success()) {
              mView.onFileUploadSuccess(bean.getData(), localPath);
            } else {
              mView.onFileUploadFailed(bean.getMsg(), localPath);
            }
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onFileUploadFailed(throwable.getMessage(), localPath);
          }
        });
  }

  public void showLoadingDialog() {
    mView.showLoading();
  }

  public void dismissLoadingDialog() {
    mView.hideLoading();
  }
}
