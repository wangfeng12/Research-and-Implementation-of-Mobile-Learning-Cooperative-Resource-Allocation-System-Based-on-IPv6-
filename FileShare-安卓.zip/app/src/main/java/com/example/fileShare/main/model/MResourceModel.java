package com.example.fileShare.main.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.main.contract.MResourceContract;
import com.example.fileShare.net.RetrofitClient;
import com.example.fileShare.search.dto.FileDto;

import java.util.List;

import io.reactivex.Flowable;

public class MResourceModel implements MResourceContract.Model {
  public Flowable<BaseObjectBean<List<FileDto>>> uploadResources(String userId) {
    return RetrofitClient.getInstance().getApi().uploadFiles(userId, "0", "1000");
  }

  public Flowable<BaseObjectBean<List<FileDto>>> downloadResources(String userId) {
    return RetrofitClient.getInstance().getApi().downloadFiles(userId, "0", "1000");
  }
}
