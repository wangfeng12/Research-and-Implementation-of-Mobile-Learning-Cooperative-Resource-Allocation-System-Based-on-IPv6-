package com.example.fileShare.main.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fileShare.R;

public class FilesViewHolder extends RecyclerView.ViewHolder {
  public ImageView fileIcon;
  public TextView fileName;
  public FilesViewHolder(@NonNull View itemView) {
    super(itemView);
    fileIcon = itemView.findViewById(R.id.file_icon_iv);
    fileName = itemView.findViewById(R.id.file_name_tv);
  }
}
