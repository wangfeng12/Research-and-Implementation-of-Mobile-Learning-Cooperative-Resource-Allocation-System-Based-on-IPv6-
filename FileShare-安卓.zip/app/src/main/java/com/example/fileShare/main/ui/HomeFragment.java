package com.example.fileShare.main.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.lifecycle.Lifecycle;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.amap.api.location.AMapLocation;
import com.example.fileShare.Constant;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpFragment;
import com.example.fileShare.base.IONRecyclerViewItemClickListener;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.search.FileTypeListActivity;
import com.example.fileShare.search.SearchActivity;
import com.example.fileShare.search.constract.SearchContract;
import com.example.fileShare.search.dto.FileDto;
import com.example.fileShare.search.presenter.SearchPresenter;
import com.example.fileShare.user_info.contract.UpdateUserInfoContract;
import com.example.fileShare.user_info.presenter.UpdateUserInfoPresenter;
import com.example.fileShare.util.LocationUtils;
import com.example.fileShare.util.ProgressDialog;
import com.example.fileShare.widget.IndicatorView;
import com.stx.xhb.pagemenulibrary.PageMenuLayout;
import com.stx.xhb.pagemenulibrary.holder.AbstractHolder;
import com.stx.xhb.pagemenulibrary.holder.PageMenuViewHolderCreator;
import com.uber.autodispose.AutoDispose;
import com.uber.autodispose.AutoDisposeConverter;
import com.uber.autodispose.android.lifecycle.AndroidLifecycleScopeProvider;
import com.zaaach.citypicker.CityPicker;
import com.zaaach.citypicker.adapter.OnPickListener;
import com.zaaach.citypicker.model.City;
import com.zaaach.citypicker.model.HotCity;
import com.zaaach.citypicker.model.LocateState;
import com.zaaach.citypicker.model.LocatedCity;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends BaseMvpFragment<SearchPresenter> implements SearchContract.View {
  private boolean isShowLocationCity = true;
  private List<HotCity> hotCities = new ArrayList<>();
  public static AMapLocation aMapLocation;
  private CityPicker cityPicker;
  private TextView cityTextView;
  private IndicatorView entranceIndicatorView;
  private PageMenuLayout mPageMenuLayout;
  private List<PageMenuEntity> homeEntrances;
  private RadioGroup homeRadioGroup;
  private RadioButton hotRb;
  private RadioButton newsRb;
  private RadioButton nearByRb;
  private FilesAdapter filesAdapter;
  private UpdateUserInfoPresenter updateUserInfoPresenter;

  protected void initView(View view) {
    mPresenter = new SearchPresenter();
    mPresenter.attachView(this);
    updateUserInfoPresenter = new UpdateUserInfoPresenter();
    updateUserInfoPresenter.attachView(new UpdateUserInfoContract.View() {
      public void onUpdateUserInfoFailed(String msg) {

      }

      public void onUpdateInfoSuccess() {

      }

      public void showLoading() {

      }

      public void hideLoading() {

      }

      public void onError(Throwable throwable) {

      }

      public <T> AutoDisposeConverter<T> bindAutoDispose() {
        return AutoDispose.autoDisposable(AndroidLifecycleScopeProvider
            .from(HomeFragment.this, Lifecycle.Event.ON_DESTROY));
      }
    });
    hotCities.add(new HotCity("北京", "北京", "101010100")); //code为城市代码
    hotCities.add(new HotCity("上海", "上海", "101020100"));
    hotCities.add(new HotCity("广州", "广东", "101280101"));
    cityPicker = CityPicker.from(HomeFragment.this)
        .enableAnimation(true)
        .setHotCities(hotCities)  //指定热门城市
        .setOnPickListener(new OnPickListener() {
          public void onPick(int position, City data) {
            cityTextView.setText(data.getName());
          }

          public void onCancel() {
          }

          public void onLocate() {
          }
        });
    cityTextView = view.findViewById(R.id.m_city_tv);
    view.findViewById(R.id.city_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        cityPicker.show();
      }
    });

    initMenuView(view);
    initFilesList(view);
    homeRadioGroup = view.findViewById(R.id.home_radio_group);
    homeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
      public void onCheckedChanged(RadioGroup group, int checkedId) {
        filesAdapter.list.clear();
        filesAdapter.notifyDataSetChanged();
        if (checkedId == hotRb.getId()) {
          mPresenter.search("", 1, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
        } else if (checkedId == newsRb.getId()) {
          mPresenter.search("", 2, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
        } else if (checkedId == nearByRb.getId()) {
          mPresenter.search("", 3, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
        }
      }
    });
    hotRb = view.findViewById(R.id.hot_rb);
    hotRb.setChecked(true);
    newsRb = view.findViewById(R.id.news_rb);
    nearByRb = view.findViewById(R.id.nearby_rb);

    view.findViewById(R.id.search_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(getActivity(), SearchActivity.class);
        mContext.gotoActivity(mIntent);
      }
    });


  }

  private void initFilesList(View view) {
    filesAdapter = new FilesAdapter();
    RecyclerView recyclerView = view.findViewById(R.id.files_list);
    StaggeredGridLayoutManager glm = new StaggeredGridLayoutManager(4, StaggeredGridLayoutManager.VERTICAL);
    recyclerView.setLayoutManager(glm);
    recyclerView.setAdapter(filesAdapter);
    filesAdapter.setItemClickListener(new IONRecyclerViewItemClickListener() {
      public void onItemClick(RecyclerView.ViewHolder holder) {
        mPresenter.downLoadFile(filesAdapter.list.get(holder.getLayoutPosition()).ipv4url,
            Constant.DOWNLOAD_FILE_PATH + filesAdapter.list.get(holder.getLayoutPosition()).filename,
            filesAdapter.list.get(holder.getLayoutPosition()).id);
      }
    });
  }

  private void initMenuView(View view) {
    homeEntrances = new ArrayList<>();
    homeEntrances.add(new PageMenuEntity("政治", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("视频", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("书籍", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("音乐", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("娱乐", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("体育", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("应用", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("图片", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("摄影写真", R.mipmap.ic_launcher_round));
    homeEntrances.add(new PageMenuEntity("丽人", R.mipmap.ic_launcher_round));
    entranceIndicatorView = view.findViewById(R.id.page_menu_indicator);
    entranceIndicatorView.setIndicatorCount(2);
    mPageMenuLayout = view.findViewById(R.id.pagemenu);
    mPageMenuLayout.setPageDatas(homeEntrances, new PageMenuViewHolderCreator() {
      public AbstractHolder createHolder(View itemView) {
        return new AbstractHolder<PageMenuEntity>(itemView) {
          private TextView entranceNameTextView;
          private ImageView entranceIconImageView;

          protected void initView(View itemView) {
            entranceIconImageView = itemView.findViewById(R.id.page_menu_icon);
            entranceNameTextView = itemView.findViewById(R.id.page_menu_name);
          }

          public void bindView(RecyclerView.ViewHolder holder, final PageMenuEntity data, int pos) {
            entranceNameTextView.setText(data.getName());
            entranceIconImageView.setImageResource(data.getImage());
            holder.itemView.setOnClickListener(new View.OnClickListener() {
              public void onClick(View v) {
                Intent mIntent = new Intent(mContext, FileTypeListActivity.class);
                mIntent.putExtra("TYPE", homeEntrances.get(holder.getLayoutPosition()).getName());
                mContext.gotoActivity(mIntent);
              }
            });
          }
        };
      }

      public int getLayoutId() {
        return R.layout.item_page_menu;
      }
    });
    mPageMenuLayout.setOnPageListener(new ViewPager.OnPageChangeListener() {
      public void onPageScrolled(int i, float v, int i1) {

      }

      public void onPageSelected(int i) {
        entranceIndicatorView.setCurrentIndicator(i);
      }

      public void onPageScrollStateChanged(int i) {

      }
    });
  }

  protected void initData(Bundle savedInstanceState) {

    LocationUtils.getInstance().addILocationListener(new LocationUtils.ILocationListener() {
      public void onLocation(AMapLocation aMapLocation) {
        if (isShowLocationCity) {
          cityTextView.setText(aMapLocation.getCity());
          isShowLocationCity = false;
        }
        HomeFragment.this.aMapLocation = aMapLocation;
        cityPicker.locateComplete(new LocatedCity(aMapLocation.getCity(), aMapLocation.getProvince(), aMapLocation.getCityCode()), LocateState.SUCCESS);
        updateUserInfoPresenter.updateUserInfo(SharedPreferencesUserInfo.getInstance().getUserInfoDto().avatar,
            SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "",
            SharedPreferencesUserInfo.getInstance().getUserInfoDto().nickname,
            SharedPreferencesUserInfo.getInstance().getUserInfoDto().phone,
            SharedPreferencesUserInfo.getInstance().getUserInfoDto().email,
            aMapLocation.getLatitude() + "",
            aMapLocation.getLongitude() + "");
      }

      public void onError(String msg) {

      }
    });

  }

  protected int getLayoutId() {
    return R.layout.fragment_home;
  }

  public void onSearchFailed(String msg) {
    showToast(msg);
    filesAdapter.list.clear();
    filesAdapter.notifyDataSetChanged();
  }

  public void onSearchSuccess(List<FileDto> bean) {
    filesAdapter.list.clear();
    filesAdapter.list.addAll(bean);
    filesAdapter.notifyDataSetChanged();
  }

  public void downloadProgress(long totalByte, long currentByte, int progress) {
    ProgressDialog.getInstance().setContentString(String.format("正在下载..  %s / %s", currentByte, totalByte));
  }

  public void downloadSuccess(String filePath) {
    showToast("下载成功");
    mPresenter.openFile(filePath, mContext);
  }

  public void downloadFailed(String msg) {
    showToast(msg);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(getContext());
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {

  }

  public void onHiddenChanged(boolean hidden) {
    super.onHiddenChanged(hidden);
    if (!hidden) {
      if (hotRb.isChecked()) {
        mPresenter.search("", 1, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      } else if (newsRb.isChecked()) {
        mPresenter.search("", 2, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      } else if (nearByRb.isChecked()) {
        mPresenter.search("", 3, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      }
    }
  }
}
