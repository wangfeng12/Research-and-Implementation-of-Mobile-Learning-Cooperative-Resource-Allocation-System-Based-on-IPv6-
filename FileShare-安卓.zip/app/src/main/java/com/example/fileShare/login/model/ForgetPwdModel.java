package com.example.fileShare.login.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.ForgetPwdContract;
import com.example.fileShare.login.contract.RegisterContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.net.RetrofitClient;

import io.reactivex.Flowable;

public class ForgetPwdModel implements ForgetPwdContract.Model {

  public Flowable<BaseObjectBean<String>> forgetPwd(String username, String password, String phone) {
    return RetrofitClient.getInstance().getApi().forgetPwd(username, password, phone);
  }
}
