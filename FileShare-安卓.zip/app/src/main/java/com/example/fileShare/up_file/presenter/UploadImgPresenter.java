package com.example.fileShare.up_file.presenter;


import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.net.RxScheduler;
import com.example.fileShare.up_file.contract.UploadImgContract;
import com.example.fileShare.up_file.model.UploadImgModel;

import java.io.File;

import io.reactivex.functions.Consumer;

public class UploadImgPresenter extends BasePresenter<UploadImgContract.View> implements UploadImgContract.Presenter {

  private UploadImgContract.Model model;

  public UploadImgPresenter() {
    model = new UploadImgModel();
  }

  public void upload(File file) {
    if (!isViewAttached()) {
      return;
    }
    model.uploadImage(file)
        .compose(RxScheduler.<BaseObjectBean<String>>Flo_io_main())
        .as(mView.<BaseObjectBean<String>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<String>>() {
          public void accept(BaseObjectBean<String> bean) throws Exception {
            if (bean.success()) {
              mView.onUploadImageSuccess(bean.getData());
            } else {
              mView.onUploadImageFailed(bean.getMsg());
            }
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
          }
        });
  }
}
