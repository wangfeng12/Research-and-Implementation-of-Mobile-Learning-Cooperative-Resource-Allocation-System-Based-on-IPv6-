package com.example.fileShare.user_info;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.up_file.contract.UploadImgContract;
import com.example.fileShare.up_file.presenter.UploadImgPresenter;
import com.example.fileShare.user_info.contract.UpdateUserInfoContract;
import com.example.fileShare.user_info.presenter.UpdateUserInfoPresenter;
import com.example.fileShare.util.ProgressDialog;
import com.example.fileShare.util.SelectorImgPopwindow;
import com.example.fileShare.util.SystemUtil;
import com.jph.takephoto.model.TResult;

import java.io.File;

public class UserInfoActivity extends BaseMvpActivity<UpdateUserInfoPresenter> implements UpdateUserInfoContract.View, UploadImgContract.View {
  private TextView accountTv;
  private EditText nickNameEt;
  private EditText emailEt;
  private EditText phoneEt;
  private ImageView userHeaderIv;
  private UserInfoDto userInfo;
  private UploadImgPresenter uploadImgPresenter;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView("我的资料", true, true);
    userHeaderIv = this.findViewById(R.id.user_header_iv);
    Glide.with(UserInfoActivity.this).load(userInfo.avatar).into(userHeaderIv);
    userHeaderIv.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        SelectorImgPopwindow.getInstance().showPop(UserInfoActivity.this, getTakePhoto(),
            true, true, 1024, 600, 600);
      }
    });
    accountTv = this.findViewById(R.id.account_tv);
    nickNameEt = this.findViewById(R.id.nike_name_et);
    emailEt = this.findViewById(R.id.email_et);
    phoneEt = this.findViewById(R.id.phone_et);
    tv_common_right.setText("完成");
    tv_common_right.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        String nikeName = nickNameEt.getText().toString();
        String email = emailEt.getText().toString();
        String phone = phoneEt.getText().toString();
        if (nikeName.isEmpty()) {
          showToast("昵称不能为空");
          return;
        }
        if (email.isEmpty()) {
          showToast("邮箱不能为空");
          return;
        }
        if (phone.isEmpty()) {
          showToast("手机号码不能为空");
          return;
        }
        if (!SystemUtil.isMobileNO(phone)) {
          showToast("手机号码格式不正确");
          return;
        }
        userInfo.nickname = nikeName;
        userInfo.email = email;
        userInfo.phone = phone;
        if (userInfo.avatar == null || userInfo.avatar.startsWith("http")) {
          mPresenter.updateUserInfo(userInfo.avatar, userInfo.id + "", nikeName, phone, email, "", "");
        } else {
          uploadImgPresenter.upload(new File(userInfo.avatar));
        }
      }
    });
    initUserInfo();
  }

  private void initUserInfo() {
    accountTv.setText(userInfo.username);
    nickNameEt.setText(userInfo.nickname);
    emailEt.setText(userInfo.email);
    phoneEt.setText(userInfo.phone);
  }

  public void takeSuccess(TResult result) {
    super.takeSuccess(result);
    userInfo.avatar = result.getImages().get(0).getCompressPath();
    Glide.with(UserInfoActivity.this).load(userInfo.avatar).into(userHeaderIv);
  }

  public int getLayoutId() {
    return R.layout.activity_user_info;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter = new UpdateUserInfoPresenter();
    mPresenter.attachView(this);
    uploadImgPresenter = new UploadImgPresenter();
    uploadImgPresenter.attachView(this);
  }

  public void initControl() {
    userInfo = SharedPreferencesUserInfo.getInstance().getUserInfoDto();
  }

  public void onUpdateUserInfoFailed(String msg) {
    showToast(msg);
  }

  public void onUpdateInfoSuccess() {
    SharedPreferencesUserInfo.getInstance().saveUserInfo(userInfo);
    showToast("保存成功");
    finish(1);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(UserInfoActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {
    showToast(throwable.getMessage());
  }

  public void onUploadImageFailed(String msg) {

  }

  public void onUploadImageSuccess(String bean) {
    userInfo.avatar = bean;
    mPresenter.updateUserInfo(userInfo.avatar,  userInfo.id + "", userInfo.nickname, userInfo.phone, userInfo.email, "", "");
  }
}
