package com.example.fileShare.login.ui;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.fileShare.login.dto.UserInfoDto;
import com.google.gson.Gson;

public class SharedPreferencesUserInfo {
  public volatile static SharedPreferencesUserInfo instance;
  private SharedPreferences sharedPreferences;
  private UserInfoDto userInfoDto;
  private Gson mGson;

  public static SharedPreferencesUserInfo getInstance() {
    if (instance == null) {
      synchronized (SharedPreferencesUserInfo.class) {
        if (instance == null) {
          instance = new SharedPreferencesUserInfo();
        }
      }
    }
    return instance;
  }

  private SharedPreferencesUserInfo() {
    mGson = new Gson();
  }

  public void init(Context mCtx) {
    sharedPreferences = mCtx.getSharedPreferences("user_info", Context.MODE_PRIVATE);
    String s = sharedPreferences.getString("userInfo", null);
    if (s != null && !s.isEmpty()) {
      userInfoDto = mGson.fromJson(s, UserInfoDto.class);
    }
  }

  public void saveUserInfo(UserInfoDto userInfo) {
    this.userInfoDto = userInfo;
    sharedPreferences.edit().putString("userInfo", mGson.toJson(userInfo)).apply();
  }

  public UserInfoDto getUserInfoDto() {
    return this.userInfoDto;
  }
}
