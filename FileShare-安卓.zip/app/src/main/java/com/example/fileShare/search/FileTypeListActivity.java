package com.example.fileShare.search;

import android.os.Bundle;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fileShare.Constant;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.base.IONRecyclerViewItemClickListener;
import com.example.fileShare.search.constract.SearchContract;
import com.example.fileShare.search.dto.FileDto;
import com.example.fileShare.search.presenter.SearchPresenter;
import com.example.fileShare.util.ProgressDialog;

import java.util.List;

public class FileTypeListActivity extends BaseMvpActivity<SearchPresenter> implements SearchContract.View {
  private SearchFileAdapter adapter;
  private String titleNameStr;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView(titleNameStr, true, shoMenu);
    initRecyclerView();
  }

  public int getLayoutId() {
    return R.layout.activity_file_type;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter.searchByType(titleNameStr);
  }

  public void initControl() {
    mPresenter = new SearchPresenter();
    mPresenter.attachView(this);
    titleNameStr = getIntent().getStringExtra("TYPE");
  }

  private void initRecyclerView() {
    adapter = new SearchFileAdapter();
    RecyclerView recyclerView = this.findViewById(R.id.files_list);
    recyclerView.setLayoutManager(new LinearLayoutManager(FileTypeListActivity.this));
    recyclerView.addItemDecoration(new DividerItemDecoration(FileTypeListActivity.this, DividerItemDecoration.VERTICAL));
    recyclerView.setAdapter(adapter);
    adapter.setItemClickListener(new IONRecyclerViewItemClickListener() {
      public void onItemClick(RecyclerView.ViewHolder holder) {
        mPresenter.downLoadFile(adapter.list.get(holder.getLayoutPosition()).ipv6url,
            Constant.DOWNLOAD_FILE_PATH + adapter.list.get(holder.getLayoutPosition()).filename,
            adapter.list.get(holder.getLayoutPosition()).id);
      }
    });
  }

  public void onSearchFailed(String msg) {
    adapter.list.clear();
    adapter.notifyDataSetChanged();
    showToast(msg);
  }

  public void onSearchSuccess(List<FileDto> bean) {
    adapter.list.clear();
    if (bean != null)
      adapter.list.addAll(bean);
    adapter.notifyDataSetChanged();
  }

  public void downloadProgress(long totalByte, long currentByte, int progress) {
    ProgressDialog.getInstance().setContentString(String.format("正在下载..  %s / %s", currentByte, totalByte));
  }

  public void downloadSuccess(String filePath) {
    showToast("下载成功");
    mPresenter.openFile(filePath, FileTypeListActivity.this);
  }

  public void downloadFailed(String msg) {
    showToast(msg);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(FileTypeListActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {
    adapter.list.clear();
    adapter.notifyDataSetChanged();
    showToast(throwable.getMessage());
  }
}
