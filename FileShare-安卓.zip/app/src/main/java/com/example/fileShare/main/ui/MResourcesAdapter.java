package com.example.fileShare.main.ui;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.fileShare.R;
import com.example.fileShare.main.entity.MResourcesEntity;
import com.example.fileShare.search.dto.FileDto;

import java.util.ArrayList;
import java.util.List;

public class MResourcesAdapter extends BaseExpandableListAdapter {
  public List<MResourcesEntity> list = new ArrayList<>();
  private Context mContext;

  public MResourcesAdapter(Context mContext) {
    this.mContext = mContext;
  }

  public int getGroupCount() {
    return list.size();
  }

  public int getChildrenCount(int groupPosition) {
    return list.get(groupPosition).files.size();
  }

  public Object getGroup(int groupPosition) {
    return list.get(groupPosition);
  }

  public Object getChild(int groupPosition, int childPosition) {
    return list.get(groupPosition).files.get(childPosition);
  }

  public long getGroupId(int groupPosition) {
    return groupPosition;
  }

  public long getChildId(int groupPosition, int childPosition) {
    return childPosition;
  }

  public boolean hasStableIds() {
    return true;
  }

  //  is Expandad 展开列表
  public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
    if (convertView == null)
      convertView = View.inflate(mContext, R.layout.resource_group_view, null);
    TextView textView = convertView.findViewById(R.id.group_txt_tv);
    textView.setText(list.get(groupPosition).title);
    ImageView arrow = convertView.findViewById(R.id.arrow);
//    if (arrow.getRotation() > 0) {
//      arrow.setRotation(arrow.getRotation() - arrow.getRotation() * 2);
//    }
//    if (isExpanded) {
//      arrow.setRotation(180f);
//    }
    return convertView;
  }

  //isLastChild 子条目内容
  public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
    ViewHolder2 holder2;
    if (convertView == null) {
      convertView = View.inflate(mContext, R.layout.resoure_child_view, null);
      holder2 = new ViewHolder2(convertView);
      convertView.setTag(holder2);
    } else {
      holder2 = (ViewHolder2) convertView.getTag();
    }
    FileDto contentInfo = list.get(groupPosition).files.get(childPosition);
    holder2.tv_name.setText(contentInfo.filename);
    //        holder2.tv_qianming.setText(list.get(groupPosition).getInfo().get(childPosition).getQianming());
    return convertView;
  }

  // 子条目是否可以被点击/选中/选择
  public boolean isChildSelectable(int groupPosition, int childPosition) {
    return true;
  }

  class ViewHolder2 {
    private TextView tv_name;

    public ViewHolder2(View view) {
      tv_name = view.findViewById(R.id.file_name_tv);
//      tv_qianming = view.findViewById(R.id.tv_qianming);
//      iv_icon = view.findViewById(R.id.iv_icon);
    }
  }

  public void onGroupExpanded(int groupPosition) {
    super.onGroupExpanded(groupPosition);
    if (listenter != null) {
      //判断是否已经打开列表的位置
      listenter.onGroupExpanded(groupPosition);
    }
  }

  /**
   * 设置判断是否点击多个组对象的监听
   */
  public void setOnGroupExPanded(OnGroupExpanded listenter) {
    this.listenter = listenter;
  }

  interface OnGroupExpanded {
    void onGroupExpanded(int groupPostion);
  }

  OnGroupExpanded listenter;
}
