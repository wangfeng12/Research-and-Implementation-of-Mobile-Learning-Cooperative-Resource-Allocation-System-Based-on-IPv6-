package com.example.fileShare.user_info.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.LoginContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.model.LoginModel;
import com.example.fileShare.net.RxScheduler;
import com.example.fileShare.user_info.contract.UpdateUserInfoContract;
import com.example.fileShare.user_info.mode.UpdateUserInfoModel;

import io.reactivex.functions.Consumer;

public class UpdateUserInfoPresenter extends BasePresenter<UpdateUserInfoContract.View> implements UpdateUserInfoContract.Presenter {

  private UpdateUserInfoContract.Model model;

  public UpdateUserInfoPresenter() {
    model = new UpdateUserInfoModel();
  }

  public void updateUserInfo(String avatar, String id, String nickname, String phone, String email, String latitude, String longitude) {
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.updateUserInfo(avatar, id, nickname, phone, email, latitude, longitude)
        .compose(RxScheduler.<BaseObjectBean<String>>Flo_io_main())
        .as(mView.<BaseObjectBean<String>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<String>>() {
          public void accept(BaseObjectBean<String> bean) throws Exception {
            if (bean.success()) {
              mView.onUpdateInfoSuccess();
            } else {
              mView.onUpdateUserInfoFailed(bean.getMsg());
            }
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }
}
