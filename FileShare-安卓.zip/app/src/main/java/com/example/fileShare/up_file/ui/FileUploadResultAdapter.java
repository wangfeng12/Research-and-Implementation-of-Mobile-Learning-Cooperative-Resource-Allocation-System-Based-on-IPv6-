package com.example.fileShare.up_file.ui;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fileShare.R;

import java.util.List;

public class FileUploadResultAdapter extends RecyclerView.Adapter {
    private List<FileResult> resultList;

    public FileUploadResultAdapter(List<FileResult> resultList) {
        this.resultList = resultList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.activity_up_file_result_item, viewGroup,false);
        return new FileUploadResultViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        FileUploadResultViewHolder fileUploadResultViewHolder = (FileUploadResultViewHolder)viewHolder;
        fileUploadResultViewHolder.file_path_text.setText(resultList.get(i).path);
        if (resultList.get(i).isSucceed)
        fileUploadResultViewHolder.file_upload_status_image.setImageResource(R.mipmap.icon_item_success);
        else
        fileUploadResultViewHolder.file_upload_status_image.setImageResource(R.mipmap.icon_item_error);
    }

    @Override
    public int getItemCount() {
        return resultList.size();
    }
}
