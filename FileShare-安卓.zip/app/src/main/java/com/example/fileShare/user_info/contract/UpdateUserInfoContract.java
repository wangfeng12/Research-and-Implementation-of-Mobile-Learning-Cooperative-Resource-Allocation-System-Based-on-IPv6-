package com.example.fileShare.user_info.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.dto.UserInfoDto;

import io.reactivex.Flowable;

public interface UpdateUserInfoContract {
  interface Model {
    Flowable<BaseObjectBean<String>> updateUserInfo(String avatar, String id, String nickname, String phone, String email, String latitude, String longitude);
  }

  interface View extends BaseView {

    void onUpdateUserInfoFailed(String msg);

    void onUpdateInfoSuccess();
  }

  interface Presenter {
    void updateUserInfo(String avatar, String id, String nickname, String phone, String email, String latitude, String longitude);
  }
}
