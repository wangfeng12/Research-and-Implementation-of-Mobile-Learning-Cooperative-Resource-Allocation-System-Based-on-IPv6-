package com.example.fileShare.main.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseFragment;
import com.example.fileShare.feedback.FeedbackActivity;
import com.example.fileShare.login.ui.LoginActivity;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.user_info.UserInfoActivity;
import com.example.fileShare.util.ActivityManager;
import com.example.fileShare.util.LocationUtils;
import com.example.fileShare.widget.CircleImageView;
import com.mprv.wifip2p.WifiP2pActivity;
import com.mpv.blelibrary.BleMainActivity;

public class MineFragment extends BaseFragment {
  private CircleImageView userHeaderIV;
  private TextView userNikeNameTV;
  private TextView userAddressTV;

  protected void initView(View view) {
    userHeaderIV = view.findViewById(R.id.user_header_iv);
    userNikeNameTV = view.findViewById(R.id.user_name_tv);
    userAddressTV = view.findViewById(R.id.user_address_tv);
    view.findViewById(R.id.logout_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        LocationUtils.getInstance().stopLocalService();
        SharedPreferencesUserInfo.getInstance().saveUserInfo(null);
        Intent mIntent = new Intent(mContext, LoginActivity.class);
        mContext.gotoActivity(mIntent);
        ActivityManager.getAppManager().finishOtherActivity(ActivityManager.getAppManager().getActivity(LoginActivity.class));
      }
    });
    view.findViewById(R.id.mine_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(mContext, UserInfoActivity.class);
        mContext.gotoActivityForResult(mIntent, 99);
      }
    });
    view.findViewById(R.id.feedback_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(mContext, FeedbackActivity.class);
        mContext.gotoActivity(mIntent);
      }
    });
    view.findViewById(R.id.setting_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(mContext, WifiP2pActivity.class);
        mContext.gotoActivity(mIntent);
      }
    });
    view.findViewById(R.id.ble_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(mContext, BleMainActivity.class);
        mContext.gotoActivity(mIntent);
      }
    });
  }

  protected void initData(Bundle savedInstanceState) {

  }

  public void onHiddenChanged(boolean isVisibleToUser) {
    super.onHiddenChanged(isVisibleToUser);
    if (!isVisibleToUser) {
      userNikeNameTV.setText(SharedPreferencesUserInfo.getInstance().getUserInfoDto().nickname);
      Glide.with(getContext()).load(SharedPreferencesUserInfo.getInstance().getUserInfoDto().avatar).into(userHeaderIV);
      if (HomeFragment.aMapLocation != null) {
        userAddressTV.setText(HomeFragment.aMapLocation.getAddress());
      } else {
        userAddressTV.setText("正在定位...");
      }
    }
  }

  public void onResume() {
    super.onResume();
    userNikeNameTV.setText(SharedPreferencesUserInfo.getInstance().getUserInfoDto().nickname);
    Glide.with(getContext()).load(SharedPreferencesUserInfo.getInstance().getUserInfoDto().avatar).into(userHeaderIV);
    if (HomeFragment.aMapLocation != null) {
      userAddressTV.setText(HomeFragment.aMapLocation.getAddress());
    } else {
      userAddressTV.setText("正在定位...");
    }
  }

  protected int getLayoutId() {
    return R.layout.fragment_mine;
  }
}
