package com.example.fileShare.main.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.main.contract.HomeContract;
import com.example.fileShare.main.contract.NearByContract;
import com.example.fileShare.main.model.HomeModel;
import com.example.fileShare.main.model.NearByByModel;
import com.example.fileShare.net.RxScheduler;

import java.util.List;

import io.reactivex.functions.Consumer;

public class NearByPresenter extends BasePresenter<NearByContract.View> implements NearByContract.Presenter {

  private NearByContract.Model model;

  public NearByPresenter() {
    model = new NearByByModel();
  }


  public void allUser() {
    //View是否绑定 如果没有绑定，就不执行网络请求
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.allUser()
        .compose(RxScheduler.<BaseObjectBean<List<UserInfoDto>>>Flo_io_main())
        .as(mView.<BaseObjectBean<List<UserInfoDto>>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<List<UserInfoDto>>>() {
          public void accept(BaseObjectBean<List<UserInfoDto>> bean) throws Exception {
            mView.onSuccess(bean.getData());
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }
}
