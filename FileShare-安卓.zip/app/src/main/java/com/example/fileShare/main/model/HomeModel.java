package com.example.fileShare.main.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.main.contract.HomeContract;

import io.reactivex.Flowable;

public class HomeModel implements HomeContract.Model {
  @Override
  public Flowable<BaseObjectBean<LoginBean>> login(String username, String password, String rememberMe) {
    return null;
  }
}
