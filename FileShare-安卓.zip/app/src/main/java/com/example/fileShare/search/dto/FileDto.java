package com.example.fileShare.search.dto;

public class FileDto {
  public String id;
  public String createTime;
  public String updateTime;
  public String downloadTime;
  public String filename;
  public String ipv4url;
  public String ipv6url;
  public String md5;
  public String userId;
  public String mobilePath;
  public String userIp;

}
