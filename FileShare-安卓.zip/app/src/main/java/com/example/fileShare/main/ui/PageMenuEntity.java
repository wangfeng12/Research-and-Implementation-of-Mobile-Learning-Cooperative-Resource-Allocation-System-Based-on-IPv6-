package com.example.fileShare.main.ui;

public class PageMenuEntity {
  private String name = "";
  private int image;

  public PageMenuEntity(String name, int image) {
    this.image = image;
    this.name = name;
  }


  public int getImage() {
    return image;
  }

  public String getName() {
    return name;
  }
}
