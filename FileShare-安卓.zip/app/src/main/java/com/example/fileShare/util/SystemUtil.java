package com.example.fileShare.util;

import android.content.Context;
import android.text.TextUtils;

public class SystemUtil {

  public static boolean isMobileNO(String mobileNums) {
    /**
     * 判断字符串是否符合手机号码格式
     * 移动号段: 134,135,136,137,138,139,147,150,151,152,157,158,159,170,178,182,183,184,187,188
     * 联通号段: 130,131,132,145,155,156,170,171,175,176,185,186
     * 电信号段: 133,149,153,170,173,177,180,181,189
     * @param str
     * @return 待检测的字符串
     */
    String telRegex = "^(1)\\d{10}$";// "[1]"代表下一位为数字可以是几，"[0-9]"代表可以为0-9中的一个，"[5,7,9]"表示可以是5,7,9中的任意一位,[^4]表示除4以外的任何一个,\\d{9}"代表后面是可以是0～9的数字，有9位。
    if (TextUtils.isEmpty(mobileNums))
      return false;
    else
      return mobileNums.matches(telRegex);
  }

  /**
   * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
   *
   * @param context
   * @param dpValue 要转换的dp值
   */
  public static int dip2px(Context context, float dpValue) {
    final float scale = context.getResources().getDisplayMetrics().density;
    return (int) (dpValue * scale + 0.5f);
  }

  /**
   * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
   *
   * @param context
   * @param pxValue 要转换的px值
   */
  public static int px2dip(Context context, float pxValue) {
    final float scale = context.getResources().getDisplayMetrics().density;
    return (int) (pxValue / scale + 0.5f);
  }

  public static int getScreenHeight(Context context) {
    return context.getResources().getDisplayMetrics().heightPixels;
  }
}
