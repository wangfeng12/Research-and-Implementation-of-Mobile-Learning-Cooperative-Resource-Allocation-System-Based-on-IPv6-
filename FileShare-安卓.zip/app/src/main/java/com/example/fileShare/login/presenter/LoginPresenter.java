package com.example.fileShare.login.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.LoginContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.model.LoginModel;
import com.example.fileShare.net.RxScheduler;

import io.reactivex.functions.Consumer;

public class LoginPresenter extends BasePresenter<LoginContract.View> implements LoginContract.Presenter {

  private LoginContract.Model model;

  public LoginPresenter() {
    model = new LoginModel();
  }

  public void login(String username, String password) {
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.login(username, password)
        .compose(RxScheduler.<BaseObjectBean<UserInfoDto>>Flo_io_main())
        .as(mView.<BaseObjectBean<UserInfoDto>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<UserInfoDto>>() {
          public void accept(BaseObjectBean<UserInfoDto> bean) throws Exception {
            if (bean.success()) {
              mView.onLoginSuccess(bean.getData());
            } else {
              mView.onLoginFailed(bean.getMsg());
            }
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }
}
