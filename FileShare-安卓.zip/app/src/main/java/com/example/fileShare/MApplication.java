package com.example.fileShare;

import android.app.Application;

import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import com.example.fileShare.login.ui.SharedPreferencesUserInfo;

import me.jessyan.retrofiturlmanager.RetrofitUrlManager;

public class MApplication extends MultiDexApplication {
  public void onCreate() {
    super.onCreate();
    MultiDex.install(this);

    RetrofitUrlManager.getInstance().setGlobalDomain("http://39.97.112.144:8889/");
    //IPV6地址
    RetrofitUrlManager.getInstance().putDomain("ipv6", "http://[2408:400a:124:c200:1af0:5fde:b90e:4f06]:8889/");
    //初始化用户信息存储
    SharedPreferencesUserInfo.getInstance().init(this);
  }
}
