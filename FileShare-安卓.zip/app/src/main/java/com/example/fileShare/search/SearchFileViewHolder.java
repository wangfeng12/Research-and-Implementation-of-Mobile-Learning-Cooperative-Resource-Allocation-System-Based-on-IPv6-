package com.example.fileShare.search;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.fileShare.R;

public class SearchFileViewHolder extends RecyclerView.ViewHolder {
  public ImageView fileIcon;
  public TextView fileName;
  public TextView fileUpdateTimeTv;

  public SearchFileViewHolder(@NonNull View itemView) {
    super(itemView);
    fileIcon = itemView.findViewById(R.id.file_icon_iv);
    fileName = itemView.findViewById(R.id.file_name_tv);
    fileUpdateTimeTv = itemView.findViewById(R.id.file_update_time_tv);
  }
}
