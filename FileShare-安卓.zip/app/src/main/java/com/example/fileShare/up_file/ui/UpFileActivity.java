package com.example.fileShare.up_file.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.bean.FileUploadBean;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.up_file.contract.FileUploadContract;
import com.example.fileShare.up_file.presenter.FileUploadPresenter;
import com.example.fileShare.util.ProgressDialog;
import com.example.file_picker.FilePicker;
import com.example.file_picker.model.FileEntity;
import com.example.file_picker.utils.Constant;
import com.example.file_picker.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class UpFileActivity extends BaseMvpActivity<FileUploadPresenter> implements FileUploadContract.View {
  private static final int REQUESTCODE_FROM_ACTIVITY = 1000;
  private static final int REQUESTCODE_FROM_ACTIVITY_RESULT = 1001;
  private View internalStorage;
  private TextView fileNumberText;
  private TextView amountSizeText;
  private Button uploadFileButton;
  private List<FileEntity> currentSelectedFilePaths = new ArrayList<>();
  private List<String> failedFilePaths = new ArrayList<>();
  private List<String> succeedFilePaths = new ArrayList<>();
  private int uploadCount = 0;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView("上传文件", true, shoMenu);
    bindView();
    resetViewInfo(0, "");

  }

  private void bindView() {
    internalStorage = findViewById(R.id.internal_storage);
    fileNumberText = findViewById(R.id.file_number);
    amountSizeText = findViewById(R.id.amount_size_text);
    uploadFileButton = findViewById(R.id.upload_file_button);

    internalStorage.setOnClickListener(allClick);
    uploadFileButton.setOnClickListener(allClick);
  }

  private void resetViewInfo(int fileNumber, String amountSize) {
    fileNumberText.setText("已选中文件 " + fileNumber + " 个");
    if (amountSize.isEmpty()) {
      amountSizeText.setText("0KB");
    } else {
      amountSizeText.setText(amountSize);
    }
    if (fileNumber > 0) {
      uploadFileButton.setEnabled(true);
    } else {
      uploadFileButton.setEnabled(false);
    }
  }

  private View.OnClickListener allClick = new View.OnClickListener() {
    public void onClick(View v) {
      if (v.getId() == internalStorage.getId()) {
        openFilePickerView();
      } else if (v.getId() == uploadFileButton.getId()) {
        uploadFileToNet();
      }
    }
  };

  private void uploadFileToNet() {
    uploadCount = 0;
    if (currentSelectedFilePaths.size() > 0) {
      showLoading();
      uploadFile();
    } else {
      showToast("还未选择任何文件哦~");
    }
  }

  private void uploadFile() {
    mPresenter.uploadFile(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "",
        new File(currentSelectedFilePaths.get(uploadCount).path),
        currentSelectedFilePaths.get(uploadCount).path, uploadCount,
        currentSelectedFilePaths.get(uploadCount).type);
  }

  private void openFilePickerView() {
    new FilePicker()
        .withActivity(UpFileActivity.this)
        .withRequestCode(REQUESTCODE_FROM_ACTIVITY)
        .withTitle("文件选择")
//                .withIconStyle(mIconType)
//                .withMutilyMode(false)
        .withMaxNum(20)
        .withStartPath("/storage/emulated/0")//指定初始显示路径
        .withNotFoundBooks("至少选择一个文件")
        .withIsGreater(false)//过滤文件大小 小于指定大小的文件
        .withFileSize(500 * 1024 * 1024)//指定文件大小为500K
//                .withChooseMode(true)//文件夹选择模式
        //.withFileFilter(new String[]{"txt", "png", "docx"})
        .start();
    resetViewInfo(0, "");
  }

  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Constant.RESULT_OK) {
      if (requestCode == REQUESTCODE_FROM_ACTIVITY) {
        currentSelectedFilePaths = (List<FileEntity>) data.getSerializableExtra(Constant.RESULT_INFO_PATHS);
        String allFileSize = data.getStringExtra(Constant.RESULT_INFO_ALL_SIZE);
        if (currentSelectedFilePaths.size() > 0) {
          resetViewInfo(currentSelectedFilePaths.size(), allFileSize);
        }
      } else if (requestCode == REQUESTCODE_FROM_ACTIVITY_RESULT) {
        currentSelectedFilePaths.clear();
        for (String path : failedFilePaths) {
          currentSelectedFilePaths.add(new FileEntity(path, ""));
        }
        failedFilePaths.clear();
        long failedFileSiz = 0;
        for (FileEntity failedPath : currentSelectedFilePaths) {
          failedFileSiz += new File(failedPath.path).length();
        }
        if (currentSelectedFilePaths.size() > 0) {
          resetViewInfo(currentSelectedFilePaths.size(), FileUtils.getReadableFileSize(failedFileSiz));
        }
      }
    } else if (resultCode == Constant.RESULT_CANCELED) {
      UpFileActivity.this.finish();
    }
  }

  public int getLayoutId() {
    return R.layout.activity_up_file;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter = new FileUploadPresenter();
    mPresenter.attachView(this);
  }

  public void initControl() {

  }

  public void showLoading() {
    ProgressDialog.getInstance().show(UpFileActivity.this);
    ProgressDialog.getInstance().setContentString("正在上传   " + (uploadCount + 1) + "个/共" + currentSelectedFilePaths.size() + "个");
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {
    showToast(throwable.getMessage());
  }

  public void onFileUploadSuccess(FileUploadBean bean, String filePath) {
    uploadCount++;
      succeedFilePaths.add(filePath);
      if (uploadCount >= currentSelectedFilePaths.size()) {
        hideLoading();
        gotoUpResult();
        return;
    }
    ProgressDialog.getInstance().setContentString("正在上传   " + (uploadCount + 1) + "个/共" + currentSelectedFilePaths.size() + "个");
    uploadFile();
  }

  public void onFileUploadFailed(String msg,String filePath) {
      uploadCount++;
      failedFilePaths.add(filePath);
      if (uploadCount >= currentSelectedFilePaths.size()) {
        hideLoading();
        gotoUpResult();
        return;
    }
    ProgressDialog.getInstance().setContentString("正在上传   " + (uploadCount + 1) + "个/共" + currentSelectedFilePaths.size() + "个");
    uploadFile();
  }

  private void gotoUpResult() {
    Intent mIntent = new Intent(UpFileActivity.this, UploadFileResultActivity.class);
    mIntent.putStringArrayListExtra(Constant.RESULT_INFO_SUCCEED_PATHS, (ArrayList<String>) succeedFilePaths);
    mIntent.putStringArrayListExtra(Constant.RESULT_INFO_FAILED_PATHS, (ArrayList<String>) failedFilePaths);
    gotoActivityForResult(mIntent, REQUESTCODE_FROM_ACTIVITY_RESULT);
  }
}
