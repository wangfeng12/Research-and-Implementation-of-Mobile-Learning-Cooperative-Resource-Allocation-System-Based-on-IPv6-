package com.example.fileShare.main.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.main.entity.MResourcesEntity;
import com.example.fileShare.search.dto.FileDto;

import java.util.List;

import io.reactivex.Flowable;

public interface MResourceContract {
  interface Model {
    Flowable<BaseObjectBean<List<FileDto>>> uploadResources(String userId);
    Flowable<BaseObjectBean<List<FileDto>>> downloadResources(String userId);
  }

  interface View extends BaseView {
    void onSuccess(List<MResourcesEntity> list);
  }

  interface Presenter {
    void uploadResource(String userId);
    void downloadResources(String userId);
  }
}
