package com.example.fileShare;

import android.os.Environment;

public class Constant {
  public static final String DOWNLOAD_FILE_PATH = Environment.getExternalStorageDirectory() + "/fileShare/";
}
