package com.example.fileShare.login.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.dto.UserInfoDto;

import io.reactivex.Flowable;

public interface ForgetPwdContract {
  interface Model {
    Flowable<BaseObjectBean<String>> forgetPwd(String username, String password, String phone);
  }

  interface View extends BaseView {
    void onForgetPwdSuccess();
    void onForgetPwdFailed(String msg);
  }

  interface Presenter {
    void forgetPwd(String username, String password, String phone);
  }
}
