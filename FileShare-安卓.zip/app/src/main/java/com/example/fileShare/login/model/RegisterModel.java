package com.example.fileShare.login.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.RegisterContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.net.RetrofitClient;

import io.reactivex.Flowable;

public class RegisterModel implements RegisterContract.Model {

  public Flowable<BaseObjectBean<UserInfoDto>> register(String username, String password, String email) {
    return RetrofitClient.getInstance().getApi().register(username, password, email);
  }
}
