package com.example.fileShare.login.ui;

import android.os.Bundle;
import android.view.View;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.login.contract.RegisterContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.presenter.RegisterPresenter;
import com.example.fileShare.util.ProgressDialog;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends BaseMvpActivity<RegisterPresenter> implements RegisterContract.View {
  private TextInputEditText userNameEt;
  private TextInputEditText passwordEt;
  private TextInputEditText passwordAgainEt;
  private TextInputEditText emailEt;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView("注册新用户", true, shoMenu);
    userNameEt = this.findViewById(R.id.et_username_register);
    passwordEt = this.findViewById(R.id.et_password_register);
    passwordAgainEt = this.findViewById(R.id.et_password_again_register);
    emailEt = this.findViewById(R.id.et_email_register);
    this.findViewById(R.id.register_btn).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        String userName = userNameEt.getText().toString();
        String password = passwordEt.getText().toString();
        String password2 = passwordAgainEt.getText().toString();
        String email = emailEt.getText().toString();
        if (userName.isEmpty()) {
          showToast("请输入用户名");
          return;
        }
        if (password.isEmpty()) {
          showToast("请输入密码");
          return;
        }
        if (!password.equals(password2)) {
          showToast("两次密码输入不一致");
          return;
        }
        mPresenter.register(userName, password, email);
      }
    });
  }

  public int getLayoutId() {
    return R.layout.activity_register;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter = new RegisterPresenter();
    mPresenter.attachView(this);
  }

  public void initControl() {

  }

  public void onRegisterFailed(String msg) {
    showToast(msg);
  }

  public void onRegisterSuccess(UserInfoDto bean) {
    showToast("注册成功");
    finish(1);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(RegisterActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {
    showToast(throwable.getMessage());
  }
}
