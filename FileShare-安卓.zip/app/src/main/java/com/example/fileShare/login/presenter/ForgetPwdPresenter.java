package com.example.fileShare.login.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.ForgetPwdContract;
import com.example.fileShare.login.contract.RegisterContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.model.ForgetPwdModel;
import com.example.fileShare.login.model.RegisterModel;
import com.example.fileShare.net.RxScheduler;

import io.reactivex.functions.Consumer;

public class ForgetPwdPresenter extends BasePresenter<ForgetPwdContract.View> implements ForgetPwdContract.Presenter {

  private ForgetPwdContract.Model model;

  public ForgetPwdPresenter() {
    model = new ForgetPwdModel();
  }

  public void forgetPwd(String username, String password, String phone) {
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.forgetPwd(username, password, phone)
        .compose(RxScheduler.<BaseObjectBean<String>>Flo_io_main())
        .as(mView.<BaseObjectBean<String>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<String>>() {
          public void accept(BaseObjectBean<String> bean) throws Exception {
            if (bean.success()) {
              mView.onForgetPwdSuccess();
            } else {
              mView.onForgetPwdFailed(bean.getMsg());
            }
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }
}
