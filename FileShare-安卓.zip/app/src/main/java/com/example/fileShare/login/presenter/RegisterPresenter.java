package com.example.fileShare.login.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.RegisterContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.model.RegisterModel;
import com.example.fileShare.net.RxScheduler;

import io.reactivex.functions.Consumer;

public class RegisterPresenter extends BasePresenter<RegisterContract.View> implements RegisterContract.Presenter {

  private RegisterContract.Model model;

  public RegisterPresenter() {
    model = new RegisterModel();
  }


  public void register(String username, String password, String email) {
    //View是否绑定 如果没有绑定，就不执行网络请求
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.register(username, password, email)
        .compose(RxScheduler.<BaseObjectBean<UserInfoDto>>Flo_io_main())
        .as(mView.<BaseObjectBean<UserInfoDto>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<UserInfoDto>>() {
          public void accept(BaseObjectBean<UserInfoDto> bean) throws Exception {
            if (bean.success()) {
              mView.onRegisterSuccess(bean.getData());
            } else {
              mView.onRegisterFailed(bean.getMsg());
            }
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }
}
