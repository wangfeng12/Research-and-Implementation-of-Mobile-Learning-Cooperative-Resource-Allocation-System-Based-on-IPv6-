package com.example.fileShare.up_file.contract;


import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;

import java.io.File;

import io.reactivex.Flowable;

public interface UploadImgContract {
  public interface Model {
    Flowable<BaseObjectBean<String>> uploadImage(File file);
  }

  public interface View extends BaseView{
    void onUploadImageFailed(String msg);
    void onUploadImageSuccess(String bean);
  }

  interface Presenter {
    void upload(File file);
  }
}
