package com.example.fileShare.main.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.main.contract.MResourceContract;
import com.example.fileShare.main.entity.MResourcesEntity;
import com.example.fileShare.main.model.MResourceModel;
import com.example.fileShare.net.RxScheduler;
import com.example.fileShare.search.dto.FileDto;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import io.reactivex.functions.Consumer;

public class MResourcePresenter extends BasePresenter<MResourceContract.View> implements MResourceContract.Presenter {
  private SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  private MResourceContract.Model model;

  public MResourcePresenter() {
    model = new MResourceModel();
  }

  public void uploadResource(String userId) {
    //View是否绑定 如果没有绑定，就不执行网络请求
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.uploadResources(userId)
        .compose(RxScheduler.<BaseObjectBean<List<FileDto>>>Flo_io_main())
        .as(mView.<BaseObjectBean<List<FileDto>>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<List<FileDto>>>() {
          public void accept(BaseObjectBean<List<FileDto>> bean) throws Exception {
            mView.onSuccess(getResourcesEntities(bean, true));
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }

  private List<MResourcesEntity> getResourcesEntities(BaseObjectBean<List<FileDto>> bean, boolean isUpdate) {
    List<MResourcesEntity> list = new ArrayList<>();
    MResourcesEntity latestDay = new MResourcesEntity("今天");
    MResourcesEntity latestWeek = new MResourcesEntity("一周内");
    MResourcesEntity latestMonth = new MResourcesEntity("一个月内");
    MResourcesEntity latestLong = new MResourcesEntity("一个月以前");
    if (bean.success()) {
      for (int i = bean.getData().size() - 1; i >= 0 ; i--) {
        FileDto file = bean.getData().get(i);
        try {
          if (isLatestDay(SDF.parse(isUpdate ? file.updateTime : file.downloadTime))) {
            latestDay.files.add(file);
          } else if (isLatestWeek(SDF.parse(isUpdate ? file.updateTime : file.downloadTime))) {
            latestWeek.files.add(file);
          } else if (isLatestMonth(SDF.parse(isUpdate ? file.updateTime : file.downloadTime))) {
            latestMonth.files.add(file);
          } else {
            latestLong.files.add(file);
          }
        } catch (Exception e) {

        }
      }
      list.add(latestDay);
      list.add(latestWeek);
      list.add(latestMonth);
      list.add(latestLong);
    }
    return list;
  }

  public void downloadResources(String userId) {
    //View是否绑定 如果没有绑定，就不执行网络请求
    if (!isViewAttached()) {
      return;
    }
    mView.showLoading();
    model.downloadResources(userId)
        .compose(RxScheduler.<BaseObjectBean<List<FileDto>>>Flo_io_main())
        .as(mView.<BaseObjectBean<List<FileDto>>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<List<FileDto>>>() {
          public void accept(BaseObjectBean<List<FileDto>> bean) throws Exception {
            mView.onSuccess(getResourcesEntities(bean, false));
            mView.hideLoading();
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
            mView.hideLoading();
          }
        });
  }

  private boolean isLatestDay(Date addtime) {
    Calendar calDateA = Calendar.getInstance();
    calDateA.setTime(new Date());

    Calendar calDateB = Calendar.getInstance();
    calDateB.setTime(addtime);

    return calDateA.get(Calendar.YEAR) == calDateB.get(Calendar.YEAR)
        && calDateA.get(Calendar.MONTH) == calDateB.get(Calendar.MONTH)
        && calDateA.get(Calendar.DAY_OF_MONTH) == calDateB
        .get(Calendar.DAY_OF_MONTH);
  }

  private boolean isLatestWeek(Date addtime) {
    Calendar calendar = Calendar.getInstance();  //得到日历
    calendar.setTime(new Date());//把当前时间赋给日历
    calendar.add(Calendar.DAY_OF_MONTH, -7);
    Date before7days = calendar.getTime();
    if (before7days.getTime() < addtime.getTime()) {
      return true;
    } else {
      return false;
    }
  }
  private boolean isLatestMonth(Date addtime) {
    Calendar calendar = Calendar.getInstance();  //得到日历
    calendar.setTime(new Date());//把当前时间赋给日历
    calendar.add(Calendar.DAY_OF_MONTH, -30);
    Date before7days = calendar.getTime();
    if (before7days.getTime() < addtime.getTime()) {
      return true;
    } else {
      return false;
    }
  }
}
