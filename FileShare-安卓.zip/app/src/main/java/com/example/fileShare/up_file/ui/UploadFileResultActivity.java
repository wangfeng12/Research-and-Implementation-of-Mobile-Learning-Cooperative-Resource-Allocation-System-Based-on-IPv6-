package com.example.fileShare.up_file.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseActivity;
import com.example.file_picker.ui.FilePickerActivity;
import com.example.file_picker.utils.Constant;

import java.util.ArrayList;
import java.util.List;

public class UploadFileResultActivity extends BaseActivity {

    private Button continueUploadFileButton;
    private Button finishUploadFileButton;
    private TextView successSizeText;
    private TextView failedSizeText;
    private List<FileResult> resultList = new ArrayList<>();
    private RecyclerView resultListView;
    private FileUploadResultAdapter resultAdapter;

    protected void initView(String titleName, boolean showBack, boolean shoMenu) {
        super.initView("上传结果", true, shoMenu);
        bindView();
        resetViewInfo();

    }

    private void resetViewInfo() {
        List<String> successList = getIntent().getStringArrayListExtra(Constant.RESULT_INFO_SUCCEED_PATHS);
        List<String> failedlist = getIntent().getStringArrayListExtra(Constant.RESULT_INFO_FAILED_PATHS);
        successSizeText.setText(successList.size()+" 个");
        failedSizeText.setText(failedlist.size()+" 个");

        for (String path:successList){
            resultList.add(new FileResult(path,true));
        }
        for (String path:failedlist){
            resultList.add(new FileResult(path,false));
        }
        resultAdapter = new FileUploadResultAdapter(resultList);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        resultListView.setLayoutManager(manager);
        resultListView.setAdapter(resultAdapter);
    }

    private void bindView() {
        iv_title_back = findViewById(R.id.iv_title_back);
        successSizeText = findViewById(R.id.upload_file_success_size_text);
        failedSizeText = findViewById(R.id.upload_file_failed_size_text);
        continueUploadFileButton = findViewById(R.id.continue_upload_file_button);
        finishUploadFileButton = findViewById(R.id.finish_upload_file_button);

        resultListView = findViewById(R.id.result_list);

        iv_title_back.setOnClickListener(allClick);
        continueUploadFileButton.setOnClickListener(allClick);
        finishUploadFileButton.setOnClickListener(allClick);
    }

    private View.OnClickListener allClick = new View.OnClickListener() {
        public void onClick(View v) {
            if (v.getId() == iv_title_back.getId()) {
//                Intent intent = new Intent();
//                setResult(Constant.RESULT_CANCELED, intent);
                finish();
            } else if (v.getId() == continueUploadFileButton.getId()) {
//                Intent intent = new Intent(UploadFileResultActivity.this, FilePickerActivity.class);
//                startActivity(intent);
                finish();
            }
            else if (v.getId() == finishUploadFileButton.getId()) {
//                Intent intent = new Intent();
//                setResult(Constant.RESULT_CANCELED, intent);
                finish();
            }
        }
    };

    public int getLayoutId() {
        return R.layout.activity_up_file_result;
    }

    public void initData(Bundle savedInstanceState) {

    }

    public void initControl() {

    }

}
