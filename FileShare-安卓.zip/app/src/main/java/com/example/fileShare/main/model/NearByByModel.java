package com.example.fileShare.main.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.main.contract.HomeContract;
import com.example.fileShare.main.contract.NearByContract;
import com.example.fileShare.net.RetrofitClient;

import java.util.List;

import io.reactivex.Flowable;

public class NearByByModel implements NearByContract.Model {

  public Flowable<BaseObjectBean<List<UserInfoDto>>> allUser() {
    return RetrofitClient.getInstance().getApi().allUser();
  }
}
