package com.example.fileShare.up_file.ui;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.fileShare.R;

public class FileUploadResultViewHolder extends RecyclerView.ViewHolder {

    public TextView file_path_text;
    public ImageView file_upload_status_image;

    public FileUploadResultViewHolder(@NonNull View itemView) {
        super(itemView);
        file_path_text = itemView.findViewById(R.id.file_path_text);
        file_upload_status_image = itemView.findViewById(R.id.file_upload_status_image);
    }
}
