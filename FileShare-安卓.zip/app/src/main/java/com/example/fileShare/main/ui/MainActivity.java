package com.example.fileShare.main.ui;


import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.main.contract.HomeContract;
import com.example.fileShare.main.presenter.HomePresenter;
import com.example.fileShare.up_file.ui.UpFileActivity;
import com.example.fileShare.util.ActivityManager;
import com.example.fileShare.util.LocationUtils;
import com.example.fileShare.util.ProgressDialog;

import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends BaseMvpActivity<HomePresenter> implements HomeContract.View {
  //首页
  private HomeFragment homeFragment;
  //附近
  private NearByFragment nearByFragment;
  //资源
  private ResourcesFragment resourcesFragment;
  //我的
  private MineFragment mineFragment;
  private FragmentManager fragmentManager;
  private TextView homeBtn;
  private TextView nearByBtn;
  private TextView resourcesBtn;
  private TextView mineBtn;

  private View.OnClickListener menuClick = new View.OnClickListener() {
    public void onClick(View v) {
      clearMenuTextState();
      if (v.getId() == homeBtn.getId()) {
        homeBtn.setSelected(true);
        setTabSelection(0);
      } else if (v.getId() == nearByBtn.getId()) {
        nearByBtn.setSelected(true);
        setTabSelection(1);
      } else if (v.getId() == resourcesBtn.getId()) {
        resourcesBtn.setSelected(true);
        setTabSelection(2);
      } else if (v.getId() == mineBtn.getId()) {
        mineBtn.setSelected(true);
        setTabSelection(3);
      }
    }
  };

  public int getLayoutId() {
    return R.layout.activity_main;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter = new HomePresenter();
    mPresenter.attachView(this);
    setTabSelection(0);
    LocationUtils.getInstance().startLocalService(this);

  }

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView(titleName, showBack, shoMenu);
    this.findViewById(R.id.btn_add).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(MainActivity.this, UpFileActivity.class);
        gotoActivity(mIntent);
      }
    });
    homeBtn = this.findViewById(R.id.btn_home);
    homeBtn.setOnClickListener(menuClick);
    homeBtn.setSelected(true);
    nearByBtn = this.findViewById(R.id.btn_nearby);
    nearByBtn.setOnClickListener(menuClick);
    resourcesBtn = this.findViewById(R.id.btn_resources);
    resourcesBtn.setOnClickListener(menuClick);
    mineBtn = this.findViewById(R.id.btn_mine);
    mineBtn.setOnClickListener(menuClick);
  }

  public void onSuccess(BaseObjectBean bean) {
    Toast.makeText(this, bean.getMsg(), Toast.LENGTH_SHORT).show();
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {

  }

  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  public void initControl() {
    requestPermission();
    fragmentManager = getSupportFragmentManager();
  }

  private void requestPermission() {
    String[] perms = {
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
    };
    if (!EasyPermissions.hasPermissions(this, perms)) {
      EasyPermissions.requestPermissions(this, "需要权限", 112, perms);
    }
  }

  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
  }

  private void clearMenuTextState() {
    homeBtn.setSelected(false);
    nearByBtn.setSelected(false);
    resourcesBtn.setSelected(false);
    mineBtn.setSelected(false);
  }

  private void setTabSelection(int index) {
    FragmentTransaction transaction = fragmentManager.beginTransaction();
    hideFragments(transaction);
    switch (index) {
      case 0:
        if (homeFragment == null) {
          homeFragment = new HomeFragment();
          transaction.add(R.id.frame_content, homeFragment);
        } else {
          transaction.show(homeFragment);
        }
        break;
      case 1:
        if (nearByFragment == null) {
          // 如果ContactsFragment为空，则创建一个并添加到界面上
          nearByFragment = new NearByFragment();
          transaction.add(R.id.frame_content, nearByFragment);
        } else {
          // 如果ContactsFragment不为空，则直接将它显示出来
          transaction.show(nearByFragment);
        }
        break;
      case 2:
        if (resourcesFragment == null) {
          // 如果NewsFragment为空，则创建一个并添加到界面上
          resourcesFragment = new ResourcesFragment();
          transaction.add(R.id.frame_content, resourcesFragment);
        } else {
          // 如果NewsFragment不为空，则直接将它显示出来
          transaction.show(resourcesFragment);
        }
        break;
      case 3:
      default:
        if (mineFragment == null) {
          // 如果SettingFragment为空，则创建一个并添加到界面上
          mineFragment = new MineFragment();
          transaction.add(R.id.frame_content, mineFragment);
        } else {
          // 如果SettingFragment不为空，则直接将它显示出来
          transaction.show(mineFragment);
        }
        break;
    }
    transaction.commit();
  }

  private void hideFragments(FragmentTransaction transaction) {
    if (homeFragment != null) {
      transaction.hide(homeFragment);
    }
    if (nearByFragment != null) {
      transaction.hide(nearByFragment);
    }
    if (resourcesFragment != null) {
      transaction.hide(resourcesFragment);
    }
    if (mineFragment != null) {
      transaction.hide(mineFragment);
    }
  }

  protected void onDestroy() {
    super.onDestroy();
  }

  protected void onResume() {
    super.onResume();
  }

  private long mExitTime = 0;
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
      if ((System.currentTimeMillis() - mExitTime) > 2000) {
        showToast("再按一次退出");
        mExitTime = System.currentTimeMillis();
      } else {
        ActivityManager.getAppManager().AppExit(this);
        finish();
        System.exit(0);
      }
      return true;
    }
    return super.onKeyDown(keyCode, event);
  }
}
