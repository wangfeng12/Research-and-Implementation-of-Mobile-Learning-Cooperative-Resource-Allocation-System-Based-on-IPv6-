package com.example.fileShare.login.ui;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CheckBox;

import androidx.annotation.NonNull;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.login.contract.LoginContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.presenter.LoginPresenter;
import com.example.fileShare.main.ui.MainActivity;
import com.example.fileShare.util.ProgressDialog;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class LoginActivity extends BaseMvpActivity<LoginPresenter> implements LoginContract.View, EasyPermissions.PermissionCallbacks {

  private TextInputEditText userNameEt;
  private TextInputEditText passwordEt;
  private CheckBox rememberPwd;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView(titleName, showBack, shoMenu);
    userNameEt = this.findViewById(R.id.et_username_login);
    passwordEt = this.findViewById(R.id.et_password_login);
    rememberPwd = this.findViewById(R.id.remember_pwd);
    this.findViewById(R.id.login_btn).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        requestPermission();

      }
    });
    this.findViewById(R.id.register_btn).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(LoginActivity.this, RegisterActivity.class);
        gotoActivity(mIntent);
      }
    });
    this.findViewById(R.id.forget_password_btn).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent mIntent = new Intent(LoginActivity.this, ForgetPwdActivity.class);
        gotoActivity(mIntent);
      }
    });

    UserInfoDto userInfoDto = SharedPreferencesUserInfo.getInstance().getUserInfoDto();
    if (userInfoDto != null) {
      userNameEt.setText(userInfoDto.username);
      if (userInfoDto.rememberPwd) {
        passwordEt.setText(userInfoDto.password);
        rememberPwd.setChecked(true);
      }
    }
  }

  public int getLayoutId() {
    return R.layout.activity_login;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter = new LoginPresenter();
    mPresenter.attachView(this);
  }

  public void initControl() {

  }

  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
  }

  private void requestPermission() {
    String[] perms = {
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
    };
    if (!EasyPermissions.hasPermissions(this, perms)) {
      EasyPermissions.requestPermissions(this, "需要权限", 112, perms);
    } else {
      startLogin();
    }
  }

  private void startLogin() {
    String userName = userNameEt.getText().toString();
    String password = passwordEt.getText().toString();
    if (userName.isEmpty()) {
      showToast("请输入用户名");
      return;
    }
    if (password.isEmpty()) {
      showToast("请输入密码");
      return;
    }
    mPresenter.login(userName, password);
  }

  private void gotoMain() {
    Intent mIntent = new Intent(LoginActivity.this, MainActivity.class);
    gotoActivity(mIntent);
    new Handler().postDelayed(new Runnable() {
      public void run() {
        finish(1);
      }
    }, 100);
  }

  public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
    startLogin();
  }

  public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(LoginActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onLoginFailed(String msg) {
    showToast(msg);
  }

  public void onLoginSuccess(UserInfoDto bean) {
    bean.rememberPwd = rememberPwd.isChecked();
    SharedPreferencesUserInfo.getInstance().saveUserInfo(bean);
    showToast("登录成功");
    gotoMain();
  }

  public void onError(Throwable throwable) {
    showToast(throwable.getMessage());
  }
}
