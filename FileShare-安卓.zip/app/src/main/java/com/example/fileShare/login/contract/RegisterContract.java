package com.example.fileShare.login.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.dto.UserInfoDto;

import io.reactivex.Flowable;

public interface RegisterContract {
  interface Model {
    Flowable<BaseObjectBean<UserInfoDto>> register(String username, String password, String email);
  }

  interface View extends BaseView {
    void showLoading();

    void hideLoading();

    void onRegisterFailed(String msg);

    void onRegisterSuccess(UserInfoDto bean);
  }

  interface Presenter {
    void register(String username, String password, String email);
  }
}
