package com.example.fileShare.main.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpFragment;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.main.contract.MResourceContract;
import com.example.fileShare.main.entity.MResourcesEntity;
import com.example.fileShare.main.presenter.MResourcePresenter;
import com.example.fileShare.util.EListViewUtils;
import com.example.fileShare.util.ProgressDialog;

import java.util.List;

public class ResourcesFragment extends BaseMvpFragment<MResourcePresenter> implements MResourcesAdapter.OnGroupExpanded,
    MResourceContract.View {
  private MResourcesAdapter mAdapter;
  private ExpandableListView mListView;
  private RadioGroup mRadioGroup;
  private RadioButton mUpBtn;
  private RadioButton mDownBtn;

  protected void initView(View view) {
    mPresenter = new MResourcePresenter();
    mPresenter.attachView(this);
    initListView(view);
    mRadioGroup = view.findViewById(R.id.radio_group);
    mUpBtn = view.findViewById(R.id.m_up_btn);
    mDownBtn = view.findViewById(R.id.m_down_btn);
    mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
      public void onCheckedChanged(RadioGroup group, int checkedId) {
        if (mAdapter != null) {
          mAdapter.list.clear();
          mAdapter.notifyDataSetChanged();
        }
        if (checkedId == mUpBtn.getId()) {
          mPresenter.uploadResource(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
        } else {
          mPresenter.downloadResources(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
        }
      }
    });
    mUpBtn.setChecked(true);
  }

  private void initListView(View view) {
    mAdapter = new MResourcesAdapter(getContext());
    mListView = view.findViewById(R.id.resources_list);
    mListView.setGroupIndicator(null);
    mListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
      public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
        return false;
      }
    });
    //组对象点击监听事件
    mListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
      public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
        return false;//请务必返回false，否则分组不会展开
      }
    });
    mListView.setAdapter(mAdapter);
    mAdapter.setOnGroupExPanded(this);
  }

  protected void initData(Bundle savedInstanceState) {

  }

  public void onHiddenChanged(boolean isVisibleToUser) {
    super.onHiddenChanged(isVisibleToUser);
    if (!isVisibleToUser) {
      if (mAdapter != null) {
        mAdapter.list.clear();
        mAdapter.notifyDataSetChanged();
      }
      if (mUpBtn.isChecked()) {
        mPresenter.uploadResource(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      } else {
        mPresenter.downloadResources(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      }
    }
  }

  protected int getLayoutId() {
    return R.layout.fragment_resources;
  }

  public void onGroupExpanded(int groupPosition) {
    EListViewUtils utils = new EListViewUtils();
    utils.expandOnlyOne(groupPosition, mListView);
  }

  public void onSuccess(List<MResourcesEntity> list) {
    mAdapter.list.clear();
    mAdapter.list.addAll(list);
    mAdapter.notifyDataSetChanged();
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(mContext);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {

  }
}
