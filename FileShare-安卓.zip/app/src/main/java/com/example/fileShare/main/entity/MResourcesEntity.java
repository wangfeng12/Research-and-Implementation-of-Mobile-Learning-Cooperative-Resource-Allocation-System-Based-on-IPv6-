package com.example.fileShare.main.entity;

import com.example.fileShare.search.dto.FileDto;

import java.util.ArrayList;
import java.util.List;

public class MResourcesEntity {
  public String title;
  public List<FileDto> files = new ArrayList<>();

  public MResourcesEntity(String title) {
    this.title = title;
  }
}
