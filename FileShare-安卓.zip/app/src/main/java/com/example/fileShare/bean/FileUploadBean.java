package com.example.fileShare.bean;

public class FileUploadBean {
}
