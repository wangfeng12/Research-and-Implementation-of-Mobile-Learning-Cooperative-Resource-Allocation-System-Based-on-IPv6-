package com.example.fileShare.login.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.dto.UserInfoDto;

import io.reactivex.Flowable;

public interface LoginContract {
  interface Model {
    Flowable<BaseObjectBean<UserInfoDto>> login(String username, String password);
  }

  interface View extends BaseView {
    void showLoading();

    void hideLoading();

    void onLoginFailed(String msg);

    void onLoginSuccess(UserInfoDto bean);
  }

  interface Presenter {
    void login(String username, String password);
  }
}
