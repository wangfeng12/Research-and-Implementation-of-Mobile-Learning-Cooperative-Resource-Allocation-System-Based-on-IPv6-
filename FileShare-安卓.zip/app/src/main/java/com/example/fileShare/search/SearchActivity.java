package com.example.fileShare.search;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fileShare.Constant;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.base.IONRecyclerViewItemClickListener;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.search.constract.SearchContract;
import com.example.fileShare.search.dto.FileDto;
import com.example.fileShare.search.presenter.SearchPresenter;
import com.example.fileShare.util.ProgressDialog;

import java.util.List;

public class SearchActivity extends BaseMvpActivity<SearchPresenter> implements SearchContract.View {
  private EditText searchContentEt;
  private SearchFileAdapter adapter;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView(titleName, showBack, shoMenu);
    searchContentEt = this.findViewById(R.id.search_content_et);
    searchContentEt.addTextChangedListener(new TextWatcher() {
      public void beforeTextChanged(CharSequence s, int start, int count, int after) {

      }

      public void onTextChanged(CharSequence s, int start, int before, int count) {

      }

      public void afterTextChanged(Editable s) {
        mPresenter.search(s.toString(), 0, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
      }
    });
    this.findViewById(R.id.back_constraint).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        finish();
      }
    });
    initRecyclerView();
  }

  private void initRecyclerView() {
    adapter = new SearchFileAdapter();
    RecyclerView recyclerView = this.findViewById(R.id.search_result_list);
    recyclerView.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
    recyclerView.addItemDecoration(new DividerItemDecoration(SearchActivity.this, DividerItemDecoration.VERTICAL));
    recyclerView.setAdapter(adapter);
    adapter.setItemClickListener(new IONRecyclerViewItemClickListener() {
      public void onItemClick(RecyclerView.ViewHolder holder) {
        mPresenter.downLoadFile(adapter.list.get(holder.getLayoutPosition()).ipv6url,
            Constant.DOWNLOAD_FILE_PATH + adapter.list.get(holder.getLayoutPosition()).filename,
            adapter.list.get(holder.getLayoutPosition()).id);
      }
    });
  }

  public int getLayoutId() {
    return R.layout.activity_search;
  }

  public void initData(Bundle savedInstanceState) {
    mPresenter.search("", 0, SharedPreferencesUserInfo.getInstance().getUserInfoDto().id + "");
  }

  public void initControl() {
    mPresenter = new SearchPresenter();
    mPresenter.attachView(this);
  }

  public void onSearchFailed(String msg) {
    adapter.list.clear();
    adapter.notifyDataSetChanged();
    showToast(msg);
  }

  public void onSearchSuccess(List<FileDto> bean) {
    adapter.list.clear();
    if (bean != null)
      adapter.list.addAll(bean);
    adapter.notifyDataSetChanged();
  }

  public void downloadProgress(long totalByte, long currentByte, int progress) {
    ProgressDialog.getInstance().setContentString(String.format("正在下载..  %s / %s", currentByte, totalByte));
  }

  public void downloadSuccess(String filePath) {
    showToast("下载成功");
    mPresenter.openFile(filePath, SearchActivity.this);
  }

  public void downloadFailed(String msg) {
    showToast(msg);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(SearchActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {
    adapter.list.clear();
    adapter.notifyDataSetChanged();
    showToast(throwable.getMessage());
  }
}
