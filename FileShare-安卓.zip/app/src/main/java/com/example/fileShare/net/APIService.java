package com.example.fileShare.net;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.search.dto.FileDto;

import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

public interface APIService {

  /**
   * 登陆
   *
   * @param username 账号
   * @param password 密码
   * @return
   */
  @FormUrlEncoded
  @POST("api/user/login")
  Flowable<BaseObjectBean<UserInfoDto>> login(@Field("username") String username,
                                              @Field("password") String passsword
  );

  @FormUrlEncoded
  @POST("api/user/register")
  Flowable<BaseObjectBean<UserInfoDto>> register(
      @Field("username") String username,
      @Field("password") String password,
      @Field("email") String email
  );


  @FormUrlEncoded
  @POST("api/user/updateUser")
  Flowable<BaseObjectBean<String>> updateUserInfo(
      @Field("avatar") String avatar,
      @Field("id") String id,
      @Field("nickname") String nickname,
      @Field("phone") String phone,
      @Field("email") String email,
      @Field("latitude") String latitude,
      @Field("longitude") String longitude
  );


  /**
   * 文件上传
   *
   * @return
   */
  @Headers({"Domain-Name: ipv6"})
  @POST("api/share/add")
  Flowable<BaseObjectBean<FileUploadBean>> uploadFile(
      @Body RequestBody body);


  @GET("api/share")
  Flowable<BaseObjectBean<List<FileDto>>> search(
      @Query("page") String page,
      @Query("size") String size,
      @Query("keyword") String keyword,
      @Query("type") int type,
      @Query("userId") String userId
  );

  @GET("api/share/my")
  Flowable<BaseObjectBean<List<FileDto>>> uploadFiles(
      @Query("userId") String userId,
      @Query("page") String page,
      @Query("size") String size
  );

  @GET("api/download/my")
  Flowable<BaseObjectBean<List<FileDto>>> downloadFiles(
      @Query("userId") String userId,
      @Query("page") String page,
      @Query("size") String size
  );

  @FormUrlEncoded
  @POST("api/download/add")
  Flowable<BaseObjectBean<String>> recordDownload(
      @Field("userId") String userId,
      @Field("fileId") String fileId);

  @GET("api/user/allUser")
  Flowable<BaseObjectBean<List<UserInfoDto>>> allUser();

  @FormUrlEncoded
  @POST("api/user/findPassword")
  Flowable<BaseObjectBean<String>> forgetPwd(
      @Field("username") String username,
      @Field("password") String password,
      @Field("phone") String phone
  );

  @Multipart
  @POST("api/user/upload")
  Flowable<BaseObjectBean<String>> uploadImage(@Part MultipartBody.Part file);

  @GET("api/share/searchFileByType")
  Flowable<BaseObjectBean<List<FileDto>>> searchByType(@Query("page") String page,
                                                @Query("size") String size,
                                                @Query("fileType") String fileType);
}
