package com.example.fileShare.up_file.ui;

public class FileResult {
    public String path;
    public boolean isSucceed ;

    public FileResult(String path, boolean isSucceed) {
        this.path = path;
        this.isSucceed = isSucceed;
    }
}
