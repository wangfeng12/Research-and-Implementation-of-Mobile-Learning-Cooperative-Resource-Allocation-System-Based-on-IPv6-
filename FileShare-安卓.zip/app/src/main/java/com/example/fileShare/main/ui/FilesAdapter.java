package com.example.fileShare.main.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fileShare.R;
import com.example.fileShare.base.IONRecyclerViewItemClickListener;
import com.example.fileShare.search.dto.FileDto;

import java.util.ArrayList;
import java.util.List;

public class FilesAdapter extends RecyclerView.Adapter<FilesViewHolder> {
  public List<FileDto> list = new ArrayList<>();
  private IONRecyclerViewItemClickListener itemClickListener;

  public void setItemClickListener(IONRecyclerViewItemClickListener itemClickListener) {
    this.itemClickListener = itemClickListener;
  }

  public FilesViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
    View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_files, viewGroup, false);
    return new FilesViewHolder(view);
  }

  public void onBindViewHolder(@NonNull FilesViewHolder holder, int i) {
    holder.fileName.setText(list.get(i).filename);
    if (itemClickListener != null) {
      holder.itemView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          itemClickListener.onItemClick(holder);
        }
      });
    }
  }

  public int getItemCount() {
    return list.size();
  }
}
