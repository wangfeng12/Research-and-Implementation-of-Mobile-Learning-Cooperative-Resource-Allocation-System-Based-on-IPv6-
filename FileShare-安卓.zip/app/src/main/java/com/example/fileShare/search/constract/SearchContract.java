package com.example.fileShare.search.constract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.search.dto.FileDto;

import java.util.List;

import io.reactivex.Flowable;
import okhttp3.ResponseBody;

public interface SearchContract {
  interface Model {
    Flowable<BaseObjectBean<List<FileDto>>> search(String keyword, int type, String userId);

    Flowable<BaseObjectBean<String>> recordDownload(String userId, String fileId);

    Flowable<BaseObjectBean<List<FileDto>>> searchByType(String fileType);
  }

  interface View extends BaseView {
    void onSearchFailed(String msg);

    void onSearchSuccess(List<FileDto> bean);

    void downloadProgress(long totalByte, long currentByte, int progress);

    void downloadSuccess(String filePath);

    void downloadFailed(String msg);
  }

  interface Presenter {
    void search(String keyword, int type, String userId);

    void downLoadFile(String url, String path, String fileId);

    void searchByType(String fileType);
  }
}
