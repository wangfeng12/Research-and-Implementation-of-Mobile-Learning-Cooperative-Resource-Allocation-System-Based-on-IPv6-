package com.example.fileShare.main.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.login.dto.UserInfoDto;

import java.util.List;

import io.reactivex.Flowable;

public interface NearByContract {
  interface Model {
    Flowable<BaseObjectBean<List<UserInfoDto>>> allUser();
  }

  interface View extends BaseView {
    void onSuccess(List<UserInfoDto> bean);
  }

  interface Presenter {
    void allUser();
  }
}
