package com.example.fileShare.login.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.LoginContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.net.RetrofitClient;

import io.reactivex.Flowable;

public class LoginModel implements LoginContract.Model {

  public Flowable<BaseObjectBean<UserInfoDto>> login(String username, String password) {
    return RetrofitClient.getInstance().getApi().login(username, password);
  }
}
