package com.example.fileShare.search.model;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.net.RetrofitClient;
import com.example.fileShare.search.constract.SearchContract;
import com.example.fileShare.search.dto.FileDto;

import java.util.List;

import io.reactivex.Flowable;

public class SearchModel implements SearchContract.Model {

  public Flowable<BaseObjectBean<List<FileDto>>> search(String keyword, int type, String userId) {
    return RetrofitClient.getInstance().getApi().search("0", "100", keyword, type, userId);
  }

  public Flowable<BaseObjectBean<String>> recordDownload(String userId, String fileId) {
    return RetrofitClient.getInstance().getApi().recordDownload(userId, fileId);
  }

  public Flowable<BaseObjectBean<List<FileDto>>> searchByType(String fileType) {
    return RetrofitClient.getInstance().getApi().searchByType("0", "100", fileType);
  }

}
