package com.example.fileShare.util;

import android.app.Activity;
import android.content.Context;

import java.util.Stack;

public class ActivityManager {
  private static Stack<Activity> mActivityStack;

  /**
   * 单例模式
   */
  private ActivityManager() {
  }

  public static ActivityManager getAppManager() {
    return SingletonHolder.mInstance;
  }

  private static class SingletonHolder {
    private static final ActivityManager mInstance = new ActivityManager();
  }

  /**
   * 添加Activity到堆栈
   */
  public void addActivity(Activity activity) {
    if (mActivityStack == null) {
      mActivityStack = new Stack<>();
    }

    /**
     *
     */
    for (int i = 0, size = mActivityStack.size(); i < size; i++) {
      Activity pActivity = mActivityStack.get(i);
      if (pActivity.getClass().equals(activity.getClass())) {
        return;
      }
    }
    mActivityStack.add(activity);
  }

  /**
   * 获取当前Activity（堆栈中最后一个压入的）
   */
  public Activity currentActivity() {
    Activity activity = mActivityStack.lastElement();
    return activity;
  }

  /**
   * 结束当前Activity（堆栈中最后一个压入的）
   */
  public void finishActivity() {
    Activity activity = mActivityStack.lastElement();
    if (activity != null) {
      finishActivity(activity);
    }
  }

  /**
   * 结束指定的Activity
   */
  public void finishActivity(Activity activity) {

    if (activity != null && !activity.isFinishing()) {
      mActivityStack.remove(activity);
      activity.finish();
      activity = null;
      System.gc();
    } else if (activity != null && activity.isFinishing()) {
      mActivityStack.remove(activity);
      activity = null;
      System.gc();
    }
  }

  /**
   * 结束指定类名的Activity
   */
  public void finishActivity(Class<?> cls) {
//        Logger.e(activity.getClass()+"是否结束21"+activity.isFinishing());
    if (cls == null) {
      return;
    }
    for (int i = 0, size = mActivityStack.size(); i < size; i++) {
      Activity activity = mActivityStack.get(i);
      if (activity.getClass().equals(cls)) {
        if (activity != null) {
          finishActivity(activity);
          break;
        }
      }
    }
  }


  /**
   * 结束所有Activity
   */
  public void finishAllActivity() {
    if (mActivityStack != null && mActivityStack.size() > 0) {
      for (int i = 0, size = mActivityStack.size(); i < size; i++) {
        if (null != mActivityStack.get(i)) {
          finishActivity(mActivityStack.get(i));
          break;
        }
      }
      mActivityStack.clear();
    }
  }

  public void finishOtherActivity(Activity activity) {
    if (mActivityStack != null && mActivityStack.size() > 0) {
      for (int i = 0, size = mActivityStack.size(); i < size; i++) {
        Activity tempActivity = mActivityStack.get(i);
        if (null != tempActivity && activity != tempActivity) {
          finishActivity(tempActivity);
          break;
        }
      }
      mActivityStack.clear();
    }
  }

  /**
   * 获取指定的Activity
   *
   * @author kymjs
   */
  public Activity getActivity(Class<?> cls) {
    if (mActivityStack != null)
      for (Activity activity : mActivityStack) {
        if (activity.getClass().equals(cls)) {
          return activity;
        }
      }
    return null;
  }

  /**
   * 退出应用程序
   */
  public void AppExit(Context context) {
    try {
      //正常退出
      finishAllActivity();
      ((Activity) context).finish();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
