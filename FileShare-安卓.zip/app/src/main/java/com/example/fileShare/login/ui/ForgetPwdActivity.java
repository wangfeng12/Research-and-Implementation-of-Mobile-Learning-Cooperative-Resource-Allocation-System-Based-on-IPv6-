package com.example.fileShare.login.ui;

import android.os.Bundle;
import android.view.View;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpActivity;
import com.example.fileShare.login.contract.ForgetPwdContract;
import com.example.fileShare.login.presenter.ForgetPwdPresenter;
import com.example.fileShare.util.ProgressDialog;
import com.google.android.material.textfield.TextInputEditText;

public class ForgetPwdActivity extends BaseMvpActivity<ForgetPwdPresenter> implements ForgetPwdContract.View {

  private TextInputEditText etUserName;
  private TextInputEditText etUserPhone;
  private TextInputEditText etUserPwd;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView("找回密码", true, shoMenu);
    etUserName = this.findViewById(R.id.et_username_forget_pwd);
    etUserPhone = this.findViewById(R.id.et_phone_forget_pwd);
    etUserPwd = this.findViewById(R.id.et_password_forget_pwd);
    this.findViewById(R.id.forget_pwd_btn).setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        String userName = etUserName.getText().toString();
        String phone = etUserPhone.getText().toString();
        String pwd = etUserPwd.getText().toString();
        if (userName.isEmpty()) {
          showToast("请输入用户名");
          return;
        }
        if (phone.isEmpty()) {
          showToast("请输入密码");
          return;
        }
        if (pwd.isEmpty()) {
          showToast("请输入新密码");
          return;
        }
        mPresenter.forgetPwd(userName, pwd, phone);
      }
    });
  }

  public int getLayoutId() {
    return R.layout.activity_forget_pwd;
  }

  public void initData(Bundle savedInstanceState) {

  }

  public void initControl() {
    mPresenter = new ForgetPwdPresenter();
    mPresenter.attachView(this);
  }

  public void onForgetPwdSuccess() {
    showToast("密码重置成功");
    finish(1);
  }

  public void onForgetPwdFailed(String msg) {
    showToast(msg);
  }

  public void showLoading() {
    ProgressDialog.getInstance().show(ForgetPwdActivity.this);
  }

  public void hideLoading() {
    ProgressDialog.getInstance().dismiss();
  }

  public void onError(Throwable throwable) {

  }
}
