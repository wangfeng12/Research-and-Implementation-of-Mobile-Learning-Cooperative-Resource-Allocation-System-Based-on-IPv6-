package com.example.fileShare.login.dto;

public class UserInfoDto {
  public int id;
  public String ipv6;
  public String nickname;
  public String password;
  public String phone;
  public String email;
  public String avatar;
  public String username;
  public double latitude;
  public double longitude;
  public boolean rememberPwd;
  public double distance;
}
