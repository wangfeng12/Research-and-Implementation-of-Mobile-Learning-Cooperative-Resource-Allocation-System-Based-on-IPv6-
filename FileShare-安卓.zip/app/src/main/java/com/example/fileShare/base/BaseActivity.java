package com.example.fileShare.base;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.fileShare.R;
import com.example.fileShare.util.ActivityManager;
import com.jph.takephoto.app.TakePhotoActivity;

public abstract class BaseActivity extends TakePhotoActivity {

  /**
   * 标题栏名称
   */
  public TextView tv_title_name;
  /**
   * 标题栏左边图片返回图片
   */
  protected ImageView iv_title_back;
  /**
   * 整个标题栏
   */
  protected View ll_common_title;
  /**
   * 标题栏右侧按钮
   */
  protected TextView tv_common_right;
  /**
   * 标题栏右侧 +
   */
  protected ImageView iv_title_add;

  protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    initControl();
    setContentView(this.getLayoutId());
    ActivityManager.getAppManager().addActivity(this);
    /* 标题栏 */
    ll_common_title = findViewById(R.id.ll_common_title);
    if (ll_common_title != null) {
      /* 初始化编辑标题 */
      tv_title_name = findViewById(R.id.tv_title_name);
      tv_title_name.setTag(Integer.MAX_VALUE / 2);
      /* 标题栏左边返回 */
      iv_title_back = findViewById(R.id.iv_title_back);// 设置默认是返回
      iv_title_back.setVisibility(View.GONE);
      /* 自定义按钮，默认隐藏 */
      tv_common_right = findViewById(R.id.tv_common_right);
      tv_common_right.setVisibility(View.GONE);

      /* 右侧加号 默认隐藏 手动显示 */
      iv_title_add = findViewById(R.id.iv_title_add);
      iv_title_add.setVisibility(View.GONE);
    }
    initView("", false, false);
    initData(savedInstanceState);
  }


  protected void onDestroy() {
    super.onDestroy();
    ActivityManager.getAppManager().finishActivity(this);
  }

  /**
   * 设置布局
   *
   * @return
   */
  public abstract int getLayoutId();

  /**
   * 初始化布局后调用
   *
   * @return
   */
  public abstract void initData(Bundle savedInstanceState);

  /**
   * 初始化布局前调用
   */
  public abstract void initControl();

  /**
   * 初始化视图
   */
  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    if (tv_title_name != null)
      tv_title_name.setText(titleName);
    if (iv_title_back != null) {
      iv_title_back.setVisibility(showBack ? View.VISIBLE : View.GONE);
    }
    if (tv_common_right != null) {
      tv_common_right.setVisibility(shoMenu ? View.VISIBLE : View.GONE);
    }
    if (iv_title_back != null) {
      iv_title_back.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
          finish(1);
        }
      });
    }
  }

  /**
   * 跳转Activity 带动画
   */
  public void gotoActivity(Intent mIntent) {
    startActivity(mIntent);
    overridePendingTransition(R.anim.activity_in, R.anim.activity_out);

  }

  public void gotoActivityForResult(Intent mIntent, int requestCode) {
    startActivityForResult(mIntent, requestCode);
    overridePendingTransition(R.anim.activity_in, R.anim.activity_out);
  }

  /**
   * @param type 0:手机默认效果，1：从左向右退出
   */
  protected void finish(int type) {
    super.finish();
    if (type == 0) {//关掉activity时的默认动画。
    } else if (type == 1) {//从左向右退出
      overridePendingTransition(R.anim.slide_left_in, R.anim.slide_right_out);
    }
  }

  protected void showToast(String msg) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  }
}
