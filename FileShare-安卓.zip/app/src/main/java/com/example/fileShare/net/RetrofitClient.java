package com.example.fileShare.net;


import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import me.jessyan.retrofiturlmanager.RetrofitUrlManager;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

  private static volatile RetrofitClient instance;
  private APIService apiService;

  private RetrofitClient() {
  }

  public static RetrofitClient getInstance() {
    if (instance == null) {
      synchronized (RetrofitClient.class) {
        if (instance == null) {
          instance = new RetrofitClient();
        }
      }
    }
    return instance;
  }

  /**
   * 设置Header
   *
   * @return
   */
  private Interceptor getHeaderInterceptor() {
    return new Interceptor() {
      @Override
      public Response intercept(@NonNull Chain chain) throws IOException {
        Request original = chain.request();
        Request.Builder requestBuilder = original.newBuilder()
            //添加Token
//                        .header("token", "");
            ;
        Request request = requestBuilder.build();
        return chain.proceed(request);
      }
    };

  }

  /**
   * 设置拦截器
   *
   * @return
   */
  private Interceptor getInterceptor() {

    HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
    //显示日志
    interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

    return interceptor;
  }

  public APIService getApi() {
    OkHttpClient client = RetrofitUrlManager.getInstance().with(
        new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(getHeaderInterceptor())
            .addInterceptor(getInterceptor()))
        .build();

    Retrofit retrofit = new Retrofit.Builder()
        .client(client)
        .baseUrl(RetrofitUrlManager.getInstance().getGlobalDomain())
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .build();
    apiService = retrofit.create(APIService.class);
    return apiService;
  }


}
