package com.example.fileShare.main.presenter;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;
import com.example.fileShare.main.contract.HomeContract;
import com.example.fileShare.main.model.HomeModel;
import com.example.fileShare.net.RxScheduler;

import io.reactivex.functions.Consumer;

public class HomePresenter extends BasePresenter<HomeContract.View> implements HomeContract.Presenter {

    private HomeContract.Model model;

    public HomePresenter() {
        model = new HomeModel();
    }

    @Override
    public void login(String username, String password, String rememberMe) {
        //View是否绑定 如果没有绑定，就不执行网络请求
        if (!isViewAttached()) {
            return;
        }
        mView.showLoading();
        model.login(username, password, rememberMe)
                .compose(RxScheduler.<BaseObjectBean<LoginBean>>Flo_io_main())
                .as(mView.<BaseObjectBean<LoginBean>>bindAutoDispose())
                .subscribe(new Consumer<BaseObjectBean<LoginBean>>() {
                    @Override
                    public void accept(BaseObjectBean<LoginBean> bean) throws Exception {
                        mView.onSuccess(bean);
                        mView.hideLoading();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mView.onError(throwable);
                        mView.hideLoading();
                    }
                });
    }
}
