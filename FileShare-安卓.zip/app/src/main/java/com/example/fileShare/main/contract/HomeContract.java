package com.example.fileShare.main.contract;

import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.LoginBean;

import io.reactivex.Flowable;

public interface HomeContract {
    interface Model {
        Flowable<BaseObjectBean<LoginBean>> login(String username, String password, String rememberMe);
    }

    interface View extends BaseView {
        @Override
        void showLoading();

        @Override
        void hideLoading();

        @Override
        void onError(Throwable throwable);

        void onSuccess(BaseObjectBean<LoginBean> bean);
    }

    interface Presenter {
        /**
         * 登陆
         *
         * @param username
         * @param password
         */
        void login(String username, String password, String rememberMe);
    }
}
