package com.example.fileShare.up_file.contract;


import com.example.fileShare.base.BaseView;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;

import java.io.File;

import io.reactivex.Flowable;

public interface FileUploadContract {
  interface Model {
    Flowable<BaseObjectBean<FileUploadBean>> uploadFile(String userId, File file, String localPath, String type);
  }

  interface View extends BaseView {
    void onFileUploadSuccess(FileUploadBean bean, String filePath);
    void onFileUploadFailed(String msg, String filePath);
  }

  interface Presenter {
    void uploadFile(String userId, File file, String localPath, int position, String type);
  }
}
