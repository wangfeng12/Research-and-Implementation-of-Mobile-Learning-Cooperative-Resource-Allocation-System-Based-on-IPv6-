package com.example.fileShare.base;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
  protected BaseActivity mContext;

  public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    mContext = ((BaseActivity) getActivity());
  }

  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
    View view = inflater.inflate(this.getLayoutId(), container, false);
    initView(view);
    initData(savedInstanceState);
    return view;
  }

  public void onDestroyView() {
    super.onDestroyView();
  }

  protected abstract void initView(View view);

  protected abstract void initData(Bundle savedInstanceState);

  protected abstract int getLayoutId();

  protected void showToast(String msg) {
    Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
  }
}
