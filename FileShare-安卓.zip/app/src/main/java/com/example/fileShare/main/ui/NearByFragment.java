package com.example.fileShare.main.ui;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.LocationSource;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.example.fileShare.R;
import com.example.fileShare.base.BaseMvpFragment;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.main.contract.NearByContract;
import com.example.fileShare.main.presenter.NearByPresenter;
import com.example.fileShare.util.LocationUtils;

import java.util.List;

public class NearByFragment extends BaseMvpFragment<NearByPresenter> implements LocationUtils.ILocationListener, AMapLocationListener, NearByContract.View {
  private MapView mapView;
  private AMap aMap;
  private LocationSource.OnLocationChangedListener mListener;
  private boolean isFirst = true;

  protected void initView(View view) {
    mPresenter = new NearByPresenter();
    mPresenter.attachView(this);
    mapView = view.findViewById(R.id.map_view);
  }

  protected void initData(Bundle savedInstanceState) {
    mapView.onCreate(savedInstanceState);
    aMap = mapView.getMap();
    setLocation();
    aMap.setLocationSource(new LocationSource() {
      public void activate(OnLocationChangedListener listener) {
        mListener = listener;
      }

      public void deactivate() {
      }
    });
    aMap.setMyLocationEnabled(true);
    LocationUtils.getInstance().setLocationChangedListener(this);
    LocationUtils.getInstance().addILocationListener(this);
    mPresenter.allUser();
  }

  protected int getLayoutId() {
    return R.layout.fragment_nearby;
  }

  public void onResume() {
    super.onResume();
    mapView.onResume();
  }

  public void onPause() {
    super.onPause();
    mapView.onPause();
  }

  public void onDestroy() {
    super.onDestroy();
    mapView.onDestroy();
    LocationUtils.getInstance().stopLocalService();
  }

  public void onSaveInstanceState(Bundle outState) {
    super.onSaveInstanceState(outState);
    mapView.onSaveInstanceState(outState);
  }

  public void onLocation(AMapLocation aMapLocation) {
    if (isFirst) {
      //移动到地图到定位位置
      CameraPosition cameraPosition = new CameraPosition(new LatLng(aMapLocation.getLatitude(), aMapLocation.getLongitude()), 13, 0, 30);
      CameraUpdate cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition);
      aMap.moveCamera(cameraUpdate);
      isFirst = false;
    }
  }

  public void onError(String msg) {
    Log.i("TAG", "onError: " + msg);
  }

  private void setLocation() {
    MyLocationStyle myLocationStyle;
    myLocationStyle = new MyLocationStyle();//初始化定位蓝点样式类myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);//连续定位、且将视角移动到地图中心点，定位点依照设备方向旋转，并且会跟随设备移动。（1秒1次定位）如果不设置myLocationType，默认也会执行此种模式。
    myLocationStyle.interval(2000); //设置连续定位模式下的定位间隔，只在连续定位模式下生效，单次定位模式下不会生效。单位为毫秒。
    myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_FOLLOW_NO_CENTER);
    myLocationStyle.myLocationIcon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_m_location));
    myLocationStyle.showMyLocation(true);
    myLocationStyle.strokeColor(Color.argb(0, 0, 0, 0));// 设置圆形的边框颜色
    myLocationStyle.radiusFillColor(Color.argb(0, 0, 0, 0));// 设置圆形的填充颜色
    aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
    aMap.getUiSettings().setMyLocationButtonEnabled(true);
  }

  public void onLocationChanged(AMapLocation aMapLocation) {
    if (mListener != null && aMapLocation != null) {
      if (aMapLocation != null && aMapLocation.getErrorCode() == 0) {
        mListener.onLocationChanged(aMapLocation);// 显示系统小蓝点
      } else {
        String errText = "定位失败," + aMapLocation.getErrorCode() + ": " + aMapLocation.getErrorInfo();
      }
    }
  }

  public void showLoading() {

  }

  public void hideLoading() {

  }

  public void onError(Throwable throwable) {

  }

  public void onSuccess(List<UserInfoDto> bean) {
    for (UserInfoDto user : bean) {
      if (user.latitude != 0 && user.longitude != 0 && user.id != SharedPreferencesUserInfo.getInstance().getUserInfoDto().id) {
//        //添加地图marker
//        LatLng latLng = new LatLng(user.latitude, user.longitude);
//        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.
//            fromBitmap(BitmapFactory.decodeResource(getResources(), R.mipmap.qidian));
//        final Marker marker = aMap.addMarker(new MarkerOptions().position(latLng).icon(bitmapDescriptor));
        setMarker(user.nickname, user.latitude, user.longitude, user.id);
      }
    }
  }

  public void setMarker(String barname, double wd, double jd, int mid) {
    LayoutInflater mInflater = LayoutInflater.from(getContext());
    View view = mInflater.inflate(R.layout.item_marker, null);
    TextView textView = view.findViewById(R.id.user_nike_name);
    textView.setText(barname);

    Bitmap bitmap = convertViewToBitmap(view);

    //绘制marker
    Marker marker2 = aMap.addMarker(new MarkerOptions()
        .position(new LatLng(wd, jd)).period(mid)//添加markerID
        .icon(BitmapDescriptorFactory.fromBitmap(bitmap))
        .draggable(false));
  }

  public static Bitmap convertViewToBitmap(View view) {
    view.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
    view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
    view.buildDrawingCache();
    Bitmap bitmap = view.getDrawingCache();
    return bitmap;
  }
}
