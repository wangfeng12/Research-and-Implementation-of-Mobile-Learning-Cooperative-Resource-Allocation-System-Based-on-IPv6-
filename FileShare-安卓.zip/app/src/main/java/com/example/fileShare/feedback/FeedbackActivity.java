package com.example.fileShare.feedback;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.fileShare.R;
import com.example.fileShare.base.BaseActivity;

public class FeedbackActivity extends BaseActivity {
  private EditText feedbackContentEt;

  protected void initView(String titleName, boolean showBack, boolean shoMenu) {
    super.initView("意见反馈", true, true);
    tv_common_right.setText("提交");
    tv_common_right.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        String content = feedbackContentEt.getText().toString();
        if (content.isEmpty()) {
          showToast("请输入您的意见或反馈");
          return;
        }
        showToast("提交成功");
        finish(1);
      }
    });
    feedbackContentEt = this.findViewById(R.id.feedback_content_et);

  }

  public int getLayoutId() {
    return R.layout.activity_feedback;
  }

  public void initData(Bundle savedInstanceState) {

  }

  public void initControl() {

  }
}
