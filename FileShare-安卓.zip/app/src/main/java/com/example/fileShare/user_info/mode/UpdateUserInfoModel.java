package com.example.fileShare.user_info.mode;


import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.contract.LoginContract;
import com.example.fileShare.login.dto.UserInfoDto;
import com.example.fileShare.net.RetrofitClient;
import com.example.fileShare.user_info.contract.UpdateUserInfoContract;

import io.reactivex.Flowable;

public class UpdateUserInfoModel implements UpdateUserInfoContract.Model {

  public Flowable<BaseObjectBean<String>> updateUserInfo(String avatar, String id, String nickname, String phone, String email ,
                                                         String latitude, String longitude) {
    return RetrofitClient.getInstance().getApi().updateUserInfo(avatar, id, nickname, phone, email, latitude, longitude);
  }
}
