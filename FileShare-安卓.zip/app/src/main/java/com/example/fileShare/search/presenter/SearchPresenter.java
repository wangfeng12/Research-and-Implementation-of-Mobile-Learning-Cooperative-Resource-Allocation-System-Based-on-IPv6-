package com.example.fileShare.search.presenter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.StrictMode;

import com.example.fileShare.base.BasePresenter;
import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.login.ui.SharedPreferencesUserInfo;
import com.example.fileShare.net.RxScheduler;
import com.example.fileShare.search.constract.SearchContract;
import com.example.fileShare.search.dto.FileDto;
import com.example.fileShare.search.model.SearchModel;
import com.mprv.wifip2p.WifiConstant;
import com.qisheng.rxnet.RxNet;
import com.qisheng.rxnet.callback.DownloadCallback;

import java.io.File;
import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public class SearchPresenter extends BasePresenter<SearchContract.View> implements SearchContract.Presenter {

  public void openFile(String filepath, Activity activity) {
    Intent intent = new Intent();
    // 这是比较流氓的方法，绕过7.0的文件权限检查
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
      StrictMode.setVmPolicy(builder.build());
    }

    File file = new File(filepath);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//设置标记
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    intent.setAction(Intent.ACTION_VIEW);//动作，查看
    intent.setDataAndType(Uri.fromFile(file), WifiConstant.getMIMEType(file));//设置类型
    activity.startActivity(intent);
  }


  private SearchContract.Model model;

  public SearchPresenter() {
    model = new SearchModel();
  }

  public void search(String keyword, int type, String userId) {
    if (!isViewAttached()) {
      return;
    }
    model.search(keyword, type, userId)
        .compose(RxScheduler.<BaseObjectBean<List<FileDto>>>Flo_io_main())
        .as(mView.<BaseObjectBean<List<FileDto>>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<List<FileDto>>>() {
          public void accept(BaseObjectBean<List<FileDto>> bean) throws Exception {
            if (bean.success()) {
              mView.onSearchSuccess(bean.getData());
            } else {
              mView.onSearchFailed(bean.getMsg());
            }
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
          }
        });
  }

  public void downLoadFile(String url, String path, String fileId) {
    if (!isViewAttached()) {
      return;
    }
    RxNet.download(url, path, new DownloadCallback() {
      public void onStart(Disposable d) {
        mView.showLoading();
      }

      public void onProgress(long totalByte, long currentByte, int progress) {
        mView.downloadProgress(totalByte, currentByte, progress);
      }

      public void onFinish(File file) {
        recordDownload(SharedPreferencesUserInfo.getInstance().getUserInfoDto().id +"", fileId);
        mView.downloadSuccess(file.getPath());
        mView.hideLoading();
      }

      public void onError(String msg) {
        mView.downloadFailed(msg);
        mView.hideLoading();
      }
    });
  }

  public void searchByType(String fileType) {
    if (!isViewAttached()) {
      return;
    }
    model.searchByType(fileType)
        .compose(RxScheduler.<BaseObjectBean<List<FileDto>>>Flo_io_main())
        .as(mView.<BaseObjectBean<List<FileDto>>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<List<FileDto>>>() {
          public void accept(BaseObjectBean<List<FileDto>> bean) throws Exception {
            if (bean.success()) {
              mView.onSearchSuccess(bean.getData());
            } else {
              mView.onSearchFailed(bean.getMsg());
            }
          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
            mView.onError(throwable);
          }
        });
  }

  public void recordDownload(String userId, String fileId) {
    if (!isViewAttached()) {
      return;
    }
    model.recordDownload(userId, fileId)
        .compose(RxScheduler.<BaseObjectBean<String>>Flo_io_main())
        .as(mView.<BaseObjectBean<String>>bindAutoDispose())
        .subscribe(new Consumer<BaseObjectBean<String>>() {
          public void accept(BaseObjectBean<String> bean) throws Exception {

          }
        }, new Consumer<Throwable>() {
          public void accept(Throwable throwable) throws Exception {
          }
        });
  }
}
