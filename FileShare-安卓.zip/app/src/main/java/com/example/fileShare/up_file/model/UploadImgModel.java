package com.example.fileShare.up_file.model;

import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;
import com.example.fileShare.net.RetrofitClient;
import com.example.fileShare.up_file.contract.FileUploadContract;
import com.example.fileShare.up_file.contract.UploadImgContract;

import java.io.File;
import java.util.List;

import io.reactivex.Flowable;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UploadImgModel implements UploadImgContract.Model {
  public Flowable<BaseObjectBean<String>> uploadImage(File file) {
    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
    MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), requestFile);
    return RetrofitClient.getInstance().getApi().uploadImage(body);
  }
}
