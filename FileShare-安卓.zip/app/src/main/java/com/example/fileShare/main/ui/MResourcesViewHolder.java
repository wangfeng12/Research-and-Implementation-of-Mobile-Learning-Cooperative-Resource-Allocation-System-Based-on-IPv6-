package com.example.fileShare.main.ui;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MResourcesViewHolder extends RecyclerView.ViewHolder {

  public MResourcesViewHolder(@NonNull View itemView) {
    super(itemView);
  }
}
