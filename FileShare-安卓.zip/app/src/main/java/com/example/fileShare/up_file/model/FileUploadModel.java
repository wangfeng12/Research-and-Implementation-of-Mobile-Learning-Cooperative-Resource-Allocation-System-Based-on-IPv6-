package com.example.fileShare.up_file.model;

import com.example.fileShare.bean.BaseObjectBean;
import com.example.fileShare.bean.FileUploadBean;
import com.example.fileShare.net.RetrofitClient;
import com.example.fileShare.up_file.contract.FileUploadContract;

import java.io.File;
import java.util.List;

import io.reactivex.Flowable;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class FileUploadModel implements FileUploadContract.Model {
  public Flowable<BaseObjectBean<FileUploadBean>> uploadFile(String userId, File file, String localPath, String fileType) {
    MultipartBody.Builder builder = new MultipartBody.Builder()
        .setType(MultipartBody.FORM)//表单类型
        .addFormDataPart("fileType", fileType)
        .addFormDataPart("userId", userId)
        .addFormDataPart("mobilePath", localPath);
    RequestBody photoRequestBody = RequestBody.create(MediaType.parse("multipart/form-data"), file);
    builder.addFormDataPart("file", file.getName(), photoRequestBody);
    List<MultipartBody.Part> parts = builder.build().parts();
    return RetrofitClient.getInstance().getApi().uploadFile(builder.build());
  }
}
