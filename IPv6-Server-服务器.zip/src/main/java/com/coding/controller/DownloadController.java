package com.coding.controller;

import com.coding.common.Const;
import com.coding.common.DistanceUtil;
import com.coding.common.PageParam;
import com.coding.domain.Download;
import com.coding.domain.ShareFile;
import com.coding.domain.User;
import com.coding.mapper.DownloadMapper;
import com.coding.mapper.ShareFileMapper;
import com.coding.mapper.UserMapper;
import com.coding.service.MinIOFileService;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.guanweiming.common.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.weekend.WeekendSqls;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Api(tags = "文件下载记录")
@AllArgsConstructor
@RequestMapping(Const.API + "download")
@RestController
public class DownloadController {

    private final ShareFileMapper shareFileMapper;
    private final UserMapper userMapper;
    private final DownloadMapper downloadMapper;


    @ApiOperation("下载文件的时候，保存下载记录")
    @PostMapping("add")
    public Result<String> add(@RequestParam Long userId, @RequestParam Long fileId) throws Exception {
        Download download = new Download();
        download.setUserId(userId);
        download.setFileId(fileId);
        downloadMapper.insertSelective(download);
        return Result.createBySuccess();
    }

    @ApiOperation(value = "查看我下载的文件")
    @GetMapping("my")
    public Result<List<ShareFile>> my(PageParam pageParam, Long userId) {
        Download download = new Download();
        download.setUserId(userId);
        PageHelper.startPage(pageParam.getPage(), pageParam.getSize(), "id desc");
        List<Download> select = downloadMapper.select(download);

        /*查询下载记录具体的文件*/
        List<ShareFile> collect = select.stream().map(item -> {
            ShareFile shareFile = shareFileMapper.selectByPrimaryKey(item.getFileId());
            shareFile.setDownloadTime(item.getCreateTime());
            return shareFile;
        }).collect(Collectors.toList());
        return Result.createBySuccess(collect);
    }
}
