package com.coding.controller;

import com.coding.common.*;
import com.coding.domain.ShareFile;
import com.coding.domain.User;
import com.coding.mapper.ShareFileMapper;
import com.coding.mapper.UserMapper;
import com.coding.service.MinIOFileService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.guanweiming.common.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.weekend.WeekendSqls;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Api(tags = "文件分享")
@AllArgsConstructor
@RequestMapping(Const.API + "share")
@RestController
public class ShareController {

    private final ShareFileMapper shareFileMapper;
    private final MinIOFileService fileService;
    private final UserMapper userMapper;

    @ApiOperation("上传文件到服务器")
    @PostMapping("add")
    public Result<String> add(@RequestParam Long userId, String mobilePath, @RequestParam MultipartFile file, String fileType) throws Exception {
        ShareFile shareFile = new ShareFile();
        String md5 = DigestUtils.md5Hex(file.getBytes());
        log.info("讲文件上传到Minio系统中:{}", file.getContentType());
        String url = fileService.upload(file.getInputStream(), file.getOriginalFilename(), file.getContentType(), md5);

        String ipv4Url = Const.IPV4 + url;
        String ipv6Url = Const.IPV6 + url;
        shareFile.setMd5(md5);
        shareFile.setIpv6url(ipv6Url);
        shareFile.setIpv4url(ipv4Url);
        shareFile.setUserId(userId);
        shareFile.setMobilePath(mobilePath);
        shareFile.setFilename(file.getOriginalFilename());
        shareFile.setFileType(fileType);
        shareFileMapper.insertSelective(shareFile);
        return Result.createBySuccess();
    }


    @ApiOperation("更新分享的文件")
    @PostMapping("update")
    public Result<String> update(ShareFile shareFile) {
        shareFileMapper.updateByPrimaryKeySelective(shareFile);
        return Result.createBySuccess();
    }

    @ApiOperation("删除分享的文件")
    @PostMapping("delete/{id}")
    public Result<String> delete(@PathVariable("id") Long id) {
        shareFileMapper.deleteByPrimaryKey(id);
        return Result.createBySuccess();
    }

    @ApiOperation(value = "查看我上传的文件")
    @GetMapping("my")
    public Result<List<ShareFile>> my(PageParam pageParam, Long userId) {
        WeekendSqls<ShareFile> custom = WeekendSqls.custom();
        Example.Builder builder = Example.builder(ShareFile.class);
        custom.andEqualTo(ShareFile::getUserId, userId);
        builder.where(custom);
        PageHelper.startPage(pageParam.getPage(), pageParam.getSize(), "id desc");
        List<ShareFile> list = shareFileMapper.selectByExample(builder.build());
        return Result.createBySuccess(list);
    }

    @ApiOperation(value = "根据类型查询文件")
    @GetMapping("searchFileByType")
    public Result<List<ShareFile>> searchFileByType(PageParam pageParam, String fileType) {
        WeekendSqls<ShareFile> custom = WeekendSqls.custom();
        Example.Builder builder = Example.builder(ShareFile.class);
        custom.andEqualTo(ShareFile::getFileType, fileType);
        builder.where(custom);
        PageHelper.startPage(pageParam.getPage(), pageParam.getSize(), "id desc");
        List<ShareFile> list = shareFileMapper.selectByExample(builder.build());
        return Result.createBySuccess(list);
    }

    @ApiOperation(value = "搜索分享的文件", notes = "type=0 搜索 type=1 热门 type=2 最新 type=3 附近")
    @GetMapping("")
    public Result<List<ShareFile>> list(PageParam pageParam, String keyword, int type, Long userId) {


        WeekendSqls<ShareFile> custom = WeekendSqls.custom();
        Example.Builder builder = Example.builder(ShareFile.class);
        if (StringUtils.isNotBlank(keyword)) {
            custom.andLike(ShareFile::getFilename, "%" + keyword + "%");
        }
        builder.where(custom);
        if (type == 1 || type == 0) {
            PageHelper.startPage(pageParam.getPage(), pageParam.getSize(), "hot desc");
        } else if (type == 2) {
            PageHelper.startPage(pageParam.getPage(), pageParam.getSize(), "id desc");
        } else if (type == 3) {
            if (userId == null) {
                return Result.createByErrorMessage("附近的资源必须登录后才可以访问");
            }
            User user = userMapper.selectByPrimaryKey(userId);
            if (user == null) {
                return Result.createByErrorMessage("附近的资源必须登录后才可以访问");
            }
            List<User> users = userMapper.selectAll();
            for (User item : users) {
                item.setDistance(DistanceUtil.getDistance(user, item));
            }
            users.sort((o1, o2) -> {
                if (o1.getDistance() == o2.getDistance()) {
                    return 0;
                }
                return o1.getDistance() > o2.getDistance() ? 1 : -1;
            });
            List<ShareFile> list = Lists.newArrayList();
            for (User item : users) {
                ShareFile shareFile = new ShareFile();
                shareFile.setUserId(item.getId());
                list.addAll(shareFileMapper.select(shareFile));
            }
            return Result.createBySuccess(list);
        }
        List<ShareFile> list = shareFileMapper.selectByExample(builder.build());
        return Result.createBySuccess(list);
    }


    @ApiOperation("获取md5文件对应的url下载地址")
    @GetMapping("urls")
    public Result<List<ShareFile>> urls(@RequestParam String md5) {
        ShareFile shareFile = new ShareFile();
        shareFile.setMd5(md5);
        List<ShareFile> list = shareFileMapper.select(shareFile);
        List<Long> userIds = list.stream().map(ShareFile::getUserId).collect(Collectors.toList());
        List<User> users = userMapper.selectByIdList(userIds);
        Map<Long, User> map = Maps.newHashMap();
        for (User item : users) {
            map.put(item.getId(), item);
        }
        for (ShareFile item : list) {
            if (item.getUserId() != null) {
                User user = map.get(item.getUserId());
                if (user != null) {
                    item.setUserIp(user.getIpv6());
                }
            }
            if (item.getHot() == null) {
                item.setHot(1);
            } else {
                item.setHot(item.getHot() + 1);
            }
            shareFileMapper.updateByPrimaryKeySelective(item);
        }
        return Result.createBySuccess(list);
    }


}
