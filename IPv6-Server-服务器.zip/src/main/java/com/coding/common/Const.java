package com.coding.common;


public interface Const {
    String ADMIN = "admin/";
    String MANAGER = "manager/";
    String NAV = "nav";
    String API = "api/";
    String IPV4 = "http://39.97.112.144:9000";
    String IPV6 = "http://new_ipv6.coding-space.cn:9000";
}
