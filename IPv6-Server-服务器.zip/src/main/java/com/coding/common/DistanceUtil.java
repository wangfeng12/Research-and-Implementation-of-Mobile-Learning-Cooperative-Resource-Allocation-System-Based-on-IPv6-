package com.coding.common;

import com.coding.domain.User;
import org.gavaghan.geodesy.Ellipsoid;
import org.gavaghan.geodesy.GeodeticCalculator;
import org.gavaghan.geodesy.GeodeticCurve;
import org.gavaghan.geodesy.GlobalCoordinates;

public class DistanceUtil {
    /**
     * 根据经纬度查看两个人的距离
     *
     * @param from 第一个人
     * @param to   第二个人
     * @return 使用库计算距离
     */
    public static double getDistance(User from, User to) {
        if (from == null || to == null) {
            return 6666666;
        }
        if (from.getLatitude() == null || from.getLongitude() == null) {
            return 6666666;
        }
        if (to.getLatitude() == null || to.getLongitude() == null) {
            return 6666666;
        }
        GlobalCoordinates source = new GlobalCoordinates(from.getLatitude(), from.getLongitude());
        GlobalCoordinates target = new GlobalCoordinates(to.getLatitude(), to.getLongitude());
        GeodeticCurve geoCurve = new GeodeticCalculator().calculateGeodeticCurve(Ellipsoid.WGS84, source, target);
        return geoCurve.getEllipsoidalDistance();
    }
}
