package com.coding.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.time.LocalDateTime;



@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Table(name = "tab_share_file")
public class ShareFile extends BaseDO {

    @ApiModelProperty(value = "文件名称", example = "729c5f7fcfca4428ada9c77fd6c1e2b6.jpg")
    private String filename;

    @ApiModelProperty(value = "服务端下载地址", example = "http://117.159.17.27:10308/avatar/jpg/729c5f7fcfca4428ada9c77fd6c1e2b6.jpg")
    private String ipv4url;

    @ApiModelProperty(value = "ipv6服务端下载地址", example = "http://117.159.17.27:10308/avatar/jpg/729c5f7fcfca4428ada9c77fd6c1e2b6.jpg")
    private String ipv6url;

    @Column(nullable = false)
    @ApiModelProperty(value = "md5-用来唯一确定文件的", example = "其他")
    private String md5;

    @ApiModelProperty(value = "上传者", example = "其他")
    private Long userId;

    @ApiModelProperty(value = "上传者手机的路径")
    private String mobilePath;

    @Transient
    @ApiModelProperty(value = "上传者的ip地址")
    private String userIp;

    @ApiModelProperty(value = "点击热度值")
    private Integer hot;

    @ApiModelProperty(value = "文件类型")
    private String fileType;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Transient
    @ApiModelProperty(value = "下载时间")
    private LocalDateTime downloadTime;


}