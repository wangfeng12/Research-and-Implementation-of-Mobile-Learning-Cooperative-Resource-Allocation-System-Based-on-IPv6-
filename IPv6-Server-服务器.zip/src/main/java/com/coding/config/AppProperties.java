package com.coding.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;


@Data
@ConfigurationProperties("app")
public class AppProperties {
    /**
     * appId
     */
    private String appId;

    private String endPoint = "http://39.97.112.144:9000";
    private String ak = "admin";
    private String sk = "12345678Aa";
    private String bn = "files";
}
