package com.coding.vo;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;


@NoArgsConstructor
@Data
public class InputItem {
    private String label;
    private String name;
    private Object value;
    /**
     * 1-input 2-select
     */
    private Integer inputType;

    public InputItem(String label, String name, JSONObject json) {
        this.label = label;
        this.name = name;
        if (json.has(name)) {
            this.value = json.get(name);
        }
        inputType = 1;
        if (name.startsWith("shifou")) {
            inputType = 2;
            if (value == null) {
                value = 0;
            }
        }
    }
}
