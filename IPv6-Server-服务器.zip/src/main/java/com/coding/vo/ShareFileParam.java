package com.coding.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;



@Data
public class ShareFileParam {

    @ApiModelProperty(value = "文件名称", example = "729c5f7fcfca4428ada9c77fd6c1e2b6.jpg")
    private String filename;


    @ApiModelProperty(value = "上传者", example = "其他")
    private Long userId;


}