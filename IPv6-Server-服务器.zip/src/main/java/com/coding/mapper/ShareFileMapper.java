package com.coding.mapper;

import com.coding.domain.ShareFile;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.additional.idlist.SelectByIdListMapper;
import tk.mybatis.mapper.common.Mapper;


@Repository
public interface ShareFileMapper extends Mapper<ShareFile>, SelectByIdListMapper<ShareFile,Long> {
}
