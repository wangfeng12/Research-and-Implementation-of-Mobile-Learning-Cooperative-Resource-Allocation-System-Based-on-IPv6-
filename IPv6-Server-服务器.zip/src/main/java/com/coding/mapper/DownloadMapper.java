package com.coding.mapper;

import com.coding.domain.Download;
import com.coding.domain.ShareFile;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;


@Repository
public interface DownloadMapper extends Mapper<Download> {
}
