package com.coding.service;

import com.coding.domain.User;
import com.coding.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.guanweiming.common.utils.HttpKit;
import com.guanweiming.common.utils.Result;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;


@Slf4j
@AllArgsConstructor
@Service
public class UserService {

    private final UserMapper userMapper;


    public Result<User> login(String username, String password) {
        User user = getUserByUsernameAndPassword(username, password);
        if (user == null) {
            int count = userMapper.selectCount(null);
            /*如果第一个人登录，默认给注册上*/
            if (count == 0) {
                user = new User();
                user.setUsername(username);
                user.setPassword(password);
                user.setNickname("新用户");
                user.setPhone(String.valueOf(System.currentTimeMillis()));
                userMapper.insertSelective(user);
            } else {
                return Result.createByErrorMessage("登陆失败");
            }
        }
        HttpKit.getRequest().getSession().setAttribute("user", user);
        return Result.createBySuccess(user);
    }


    private User getUserByUsernameAndPassword(String username, String password) {
        User record = new User();
        record.setUsername(username);
        record.setPassword(password);
        PageHelper.startPage(1, 1);
        List<User> list = userMapper.select(record);
        return list.size() == 0 ? null : list.get(0);
    }


    public Result<User> addUser(String username, String password, String email) {
        User record = new User();
        record.setUsername(username);
        List<User> list = userMapper.select(record);
        if (!CollectionUtils.isEmpty(list)) {
            return Result.createByErrorMessage("用户已经存在，无法添加");
        }
        record.setPassword(password);
        record.setNickname("新用户");
        record.setEmail(email);
        record.setPhone(String.valueOf(System.currentTimeMillis()));
        int resultCount = userMapper.insertSelective(record);
        return resultCount == 0 ? Result.createByErrorMessage("添加失败") : Result.createBySuccess(record);
    }


    public Result<User> updateUser(User user) {
        userMapper.updateByPrimaryKeySelective(user);
        return Result.createBySuccess();
    }


}
